import axiosBase from "../utils/rest/axiosBase";

function fetchUserEnvironment() {
  return axiosBase.get('/env');
}

const environmentApi = {
  fetchUserEnvironment
};

export default environmentApi;
