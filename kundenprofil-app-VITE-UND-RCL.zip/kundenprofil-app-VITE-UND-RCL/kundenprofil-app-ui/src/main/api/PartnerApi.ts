import axiosBase from "../utils/rest/axiosBase";
import { AxiosResponse } from "axios";
import {Druckweg} from "./interfaces/Druckweg";
import {PartnerProfil} from "./interfaces/Partner.interface";


function fetchPartnerDaten(parNummer: string): Promise<AxiosResponse<PartnerProfil>> {
  return axiosBase.get(
    `/partner/ladePartnerByParNummer?parNummer=${encodeURIComponent(parNummer)}`
  );
}

function fetchDruckwege(parNummer: string): Promise<AxiosResponse<Druckweg[]>> {
    return axiosBase.get(
      `/partner/ladeDruckwegeByParNummer?parNummer=${encodeURIComponent(parNummer)}`
    );
}

function fetchSaveOnlineDruckweg(vsnr) {
    return axiosBase.post('/partner/speichernOnlineDruckweg', vsnr);
}

function fetchSaveOfflineDruckweg(vsnr) {
    return axiosBase.post('/partner/speichernOfflineDruckweg', vsnr);
}

function fetchSwitchAllDruckwegeToOnline(druckwege) {
    return axiosBase.post('/partner/speichernAllDruckwegeToOnline', druckwege);
}

function fetchDruckAuftraege(params) {
     const vsnr = params.vsnr;
     const ladeAktuelleDruckauftraege = params.ladeAktuelleDruckauftraege;
     const ladeHistorischDruckauftraege = params.ladeHistorischDruckauftraege;

    return axiosBase.get(
        '/partner/ladeDruckauftraege?' +
        'vsnr=:vsnr' +
        '&ladeAktuelleDruckauftraege=:ladeAktuelleDruckauftraege' +
        '&ladeHistorischDruckauftraege=:ladeHistorischDruckauftraege', {
            vsnr,
            ladeAktuelleDruckauftraege,
            ladeHistorischDruckauftraege
        },
    );
}

function fetchLadeErweiterterHaushalt(parNummer: string) {
    return axiosBase.get(`/partner/ladeErweiterterHaushalt?parNummer=${encodeURIComponent(parNummer)}`);
}

const partnerApi = {
    fetchPartnerDaten,
    fetchDruckwege,
    fetchSaveOnlineDruckweg,
    fetchSaveOfflineDruckweg,
    fetchDruckAuftraege,
    fetchSwitchAllDruckwegeToOnline,
    fetchLadeErweiterterHaushalt
};

export default partnerApi;
