export interface PartnerProfil {
    partner?: Partner;
    kundenprofil?: Kundenprofil;
    haushaltsPartner?: Partner[];
    spartenMappings?: SpartenMapping[];
}

export interface SpartenMapping {
    key: string;
    value: string;
}

export interface Partner {
    partnerNummer: number;
    anrede?: string;
    anredeCode?: number;
    name: string;
    vorname?: string;
    geburtsDatum?: string; // ISO-String für LocalDateTime
    geburtsJahr?: string;
    adressen?: PartnerAdresse[];
    sterbedatum?: string; // ISO-String für LocalDateTime
    status?: string;
    titel?: string;
    berufBezeichnung?: string;
    berufCode?: string;
    letzteAenderung?: string; // ISO-String für LocalDateTime
    scoring?: string;
    beschaeftigungsverh?: string;
    beschaeftigungCode?: string;
    familienStand?: string;
    familienStandCode?: string;
    anzahlKinder?: number;
    geburtslandCode?: string;
    geburtsOrt?: string;
    staatsangehoerigkeitCode?: string;
    haushaltsRolle?: string;
    updateZahl?: number;
}

export interface PartnerAdresse {
    validator?: any;
    adressId?: string;
    laufendeNummer?: string;
    strasse?: string;
    zusatz?: string;
    hausnummer?: string;
    plz?: string;
    ort?: string;
    land?: string;
    adressTyp?: string;
    adresstypCode?: string;
    gueltigAb?: string;      // ISO-String für LocalDateTime
    gueltigBis?: string;     // ISO-String für LocalDateTime
    inaktivAb?: string;      // ISO-String für LocalDateTime
    updateZahl?: number;
}

export interface Kundenprofil {
    parNummer?: number;
    korrelationsid?: string;
    vertriebsweg?: Vertriebsweg;
    kundeSeit?: string; // ISO-String für LocalDateTime
    zahlungsinfo?: ZahlungsInfo;
    kundenprofilRentabilitaetGesamt?: KundenprofilRentabilitaetGesamt;
    kundenprofilRentabilitaet?: KundenprofilRentabilitaet[];
    beschwerdeListeEintrag?: BeschwerdeListeEintrag[];
    mahnvertragsDaten?: MahnvertragsDatenEintrag[];
    rentaLeistungListe?: RentaLeistungListe[];
    vertragsinfoSparteListeEintrag?: VertragsinfoSparteListeEintrag[];
    vertragsinfoListeEintrag?: VertragsinfoListeEintrag[];
    kundenRentaSparteListes?: KundenRentaSparteListe[];
    rentaSchadenListes?: RentaSchadenListe[];
    besondereRollen?: BesondereRollen[];
    mahnhistorie?: Mahnhistorie[];
    uniwagnis?: Uniwagnis[];
    uniwagnisSparte?: UniwagnisSparte[];
}



export interface KundenprofilRentabilitaetGesamt {
    validator?: any;
    gesamtJahresBeitrag?: string;
    kompositSchadenquote?: string;
    anzahlLeistung?: string;
    summeLeistung?: string;
    anzahlSchaden?: string;
    summeSchaden?: string;
}

export interface Vertriebsweg {
    verNummer?: number;
    vertriebswegNummer?: string;
    vertriebswegName?: string;
    vertriebswegDatum?: string; // ISO-String für LocalDateTime
    vertriebswegSparte?: string;
}

export interface ZahlungsInfo {
    validator?: any;
    aktuellerKundensaldo?: string;
    scoringWert?: string;
    scoringDatum?: string; // ISO-String für Datum
    anzahlMahnverfahrenOffen?: string;
    anzahlMahnverfahrenHistorie?: string;
    infoText?: string;
}

export interface KundenprofilRentabilitaet {
    validator?: any;
    jahr?: string;
    beitraege?: string;
    anzahlSchaden?: string;
    schadenaufwand?: string;
    quote?: string;
}

export interface BeschwerdeListeEintrag {
    validator?: any;
    bswNummer?: string;
    bswBswNummerVorgaenger?: string;
    bswEingebFaAnmerkung?: string;
    bswEingebFaEntscheidung?: string;
    bswTelefonnotiz?: string;
}

export interface MahnvertragsDatenEintrag {
    validator?: any;
    vertrag?: string;
    saldo?: string;
    mahnverfahren?: string;
    unbezahltSeit?: string; // ISO-String für Datum
    mahnzweig?: string;
    grund?: string;
}

export interface RentaLeistungListe {
    vertrag?: string;
    sparte?: string;
    leistungsfall?: string;
    leistungsversion?: string;
    ereignisdatum?: string; // ISO-String für Datum
    zahlungen?: string;
    leistungsart?: string;
    status?: string;
}

export interface VertragsinfoSparteListeEintrag {
    validator?: any;
    sparte?: string;
    anzahlVertraege?: string;
    beitrag?: string;
    versicherungssumme?: string;
}

export interface VertragsinfoListeEintrag {
    validator?: any;
    vertag?: string;
    beitrag?: string;
    tarif?: string;
    sparte?: string;
    versicherungssumme?: string;
    vertragsbeginn?: string; // ISO-String für Datum
    systemKnz?: string;
    anzahlVertraege?: string;
}

export interface KundenRentaSparteListe {
    sparte?: string;
    jahr?: string;
    beitraege?: string;
    anzahlSchaden?: string;
    schadenaufwand?: string;
    quote?: string;
}

export interface RentaSchadenListe {
    vertrag?: string;
    sparte?: string;
    schadennummer?: string;
    tarifbuendel?: string;
    ereignisdatum?: string;   // ISO-String für Datum
    meldedatum?: string;      // ISO-String für Datum
    schadenaufwand?: string;
    reserve?: string;
    rueckkauf?: string;
    schadenart?: string;
}

export interface BesondereRollen {
    validator?: any;
    vertrag?: string;
    sparte?: string;
    parNummerVn?: string;
    rolle?: string;
}

export interface Mahnhistorie {
    vertrag?: string;
    beginndatum?: string;    // ISO-String für Datum
    endedatum?: string;      // ISO-String für Datum
    grund?: string;
    creditreform?: string;
}

export interface Uniwagnis {
    validator?: any;
    uwaw?: string;
    schadensparte?: string;
    schadenursache?: string;
    gesellschaft?: string;
}

export interface UniwagnisSparte {
    sparte?: string;
    anzahlUniwagnis?: string;
}