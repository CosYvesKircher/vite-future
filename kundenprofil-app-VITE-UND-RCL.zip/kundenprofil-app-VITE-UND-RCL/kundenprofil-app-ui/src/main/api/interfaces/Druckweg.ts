export interface Druckweg {
    vsnr: number;
    sparte: string;
    druckweg: string;
}