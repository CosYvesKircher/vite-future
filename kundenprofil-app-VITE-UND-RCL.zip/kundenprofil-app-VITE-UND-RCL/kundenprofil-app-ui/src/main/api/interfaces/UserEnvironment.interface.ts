export interface UserEnvironment {
    authenticatedUsername: string;
    db: string;
    restTimeout?: number;
    tester?: boolean;
}