import { PayloadActionCreator, createAction } from '@reduxjs/toolkit';
import {RemoteData} from "../../utils/rest/RemoteStateUtils";
import {Kundenprofil, Partner, PartnerProfil, SpartenMapping} from "../../api/interfaces/Partner.interface";
import {Druckweg} from "../../api/interfaces/Druckweg";
import {KommunikationsWeg} from "../../../API-GEN/partner-haushalt-verwalten-bas";
import {PartnerErweiterterHaushalt} from "../../../API-GEN/kundenprofil-app";

export interface ContentDataSuccessPayload {
    partnerProfilData: PartnerProfil;
    druckwegeData: Druckweg[];
    erweiterterHaushaltData: PartnerErweiterterHaushalt;
}

export type ContentStateType = {
    remote: RemoteData;
    parNummer?: string
    partner?: Partner,
    kundenprofil?: Kundenprofil,
    druckwege?: Druckweg[],
    spartenMappings?: SpartenMapping[],
    haushaltspartner?: Partner[],
    kommunikationswege:KommunikationsWeg[],
    partnererweiterterhaushalt?:Partner[],
    editVsnr:boolean
};

// SLICES
export const CONTENT_SLICE_NAME = 'content';

// ACTIONS
export const LOAD_CONTENT_DATA = `${CONTENT_SLICE_NAME}/loadContentData`;
export const loadContentDataAction: PayloadActionCreator<
    string,
    typeof LOAD_CONTENT_DATA
> = createAction(LOAD_CONTENT_DATA);

export const LOAD_CONTENT_DATA_SUCCESS = `${CONTENT_SLICE_NAME}/loadContentDataSuccess`;
export const loadContentDataSuccessAction: PayloadActionCreator<
    ContentDataSuccessPayload,
    typeof LOAD_CONTENT_DATA_SUCCESS
> = createAction(LOAD_CONTENT_DATA_SUCCESS);

export const LOAD_CONTENT_DATA_ERROR = `${CONTENT_SLICE_NAME}/loadContentDataError`;
export const loadContentDataErrorAction: PayloadActionCreator<
    string,
    typeof LOAD_CONTENT_DATA_ERROR
> = createAction(LOAD_CONTENT_DATA_ERROR);
