import {all, fork} from 'redux-saga/effects';


import {userSaga} from "./user/UserSaga";
import {contentSaga} from "./content/ContentSaga";

function* rootSaga() {
  yield all([fork(userSaga), fork(contentSaga)]);
}

export default rootSaga;
