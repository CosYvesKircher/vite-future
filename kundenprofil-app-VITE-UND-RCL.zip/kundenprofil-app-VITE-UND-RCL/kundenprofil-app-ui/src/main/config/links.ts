export const WEBAPP_CONTEXT_PATH = 'cosmos-kunde-kundenprofil-app';

const links = {
  url: {
    LOGOUT: `${WEBAPP_CONTEXT_PATH}/?logout`,
    FEEDBACK: 'www.cosmosdirekt.de' // TODO Wiki-Seite anlegen und verlinken
  }
};

export default links;
