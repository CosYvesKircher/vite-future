import React from 'react';
import AppContainer from './modules/app/AppContainer';
import { CssBaseline } from "@mui/material";

const AppRootContainer = () => (
  <>
    <CssBaseline />
    <AppContainer />
  </>
);

export default AppRootContainer;
