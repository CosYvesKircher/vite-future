import React from 'react';
import AppRootContainer from './AppRootContainer';

import {ThemeProvider} from "@mui/material";
import theme from "./styles/Theme";
import {StoreProvider} from "./store/StoreProvider";

const App = () => (
  <StoreProvider>
      <ThemeProvider theme={theme}>
        <AppRootContainer />
      </ThemeProvider>
  </StoreProvider>
);

export default App;
