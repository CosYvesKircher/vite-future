import React, {useEffect, useMemo} from 'react';
import {useDispatch, useSelector} from 'react-redux';


import AppUI from './AppUI';
import queryString from 'query-string';
import {RemoteState} from '@cos/rcl-future/enums';



import {refreshAllAction} from "../../store/user/UserStoreTypes";
import {selectUserRemote} from "../../store/user/UserSelector";
import {RemoteLoadingState} from "../../utils/rest/RemoteStateUtils";
import {loadContentDataAction} from "../../store/content/ContentStoreTypes";


function AppContainer() {
  const dispatch = useDispatch();
  const userRemoteState = useSelector(selectUserRemote);

  // Initiales Laden und triggern der User saga
  useEffect(() => {
    if (userRemoteState.loadingState === RemoteLoadingState.notLoaded) {
      console.log("AppContainer: dispatch refreshAllAction");
      dispatch(refreshAllAction())
    }
  }, [dispatch, userRemoteState]);

  const queryParams = useMemo(
      () => queryString.parse(document.location.search) || {},
      [document.location.search]
  );

  useEffect(() => {
    if (userRemoteState.loadingState !== RemoteLoadingState.loaded) return;
    let parNummer = queryParams.parNummer;
    if (Array.isArray(parNummer)) {
      parNummer = parNummer[0];
    }
    if (parNummer) {
      dispatch(loadContentDataAction(parNummer));
    }
  }, [queryParams, userRemoteState, dispatch]);

  return (
    <AppUI/>
  );
}

export default AppContainer;
