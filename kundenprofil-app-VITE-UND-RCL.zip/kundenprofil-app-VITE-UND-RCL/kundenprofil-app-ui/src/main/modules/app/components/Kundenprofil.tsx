import React from 'react';
import {Grid} from "@mui/material";
import Widget from "../../../components/Widget";
import WirtschaftlichkeitPanel from "./WirtschaftlichkeitPanel";
import VersichertesRisikoPanel from "./VersichertesRisikoPanel";
import ZahlungsmoralPanel from "./ZahlungsmoralPanel";
import PartnerPanel from "./PartnerPanel";
import Divider from '@mui/material/Divider';

function Kundenprofil() {
    return (
        <Widget title={`Informationen`}>
            <Grid container spacing={2}>
                <Divider />
                <WirtschaftlichkeitPanel />

                <Divider />
                <VersichertesRisikoPanel />

                <Divider />
                <ZahlungsmoralPanel />

                <Divider />
                <PartnerPanel />
            </Grid>
        </Widget>
    );
}

export default Kundenprofil;