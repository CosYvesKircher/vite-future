import { styled } from '@mui/material/styles';
import React from 'react';
import {formatCurrency, formatDecimal} from "../../../../utils/NumberUtils";


type NumberFormatterProps = {
    value: string;
    renderType?: 'number' | 'currency' | 'decimal' | 'quote';
};

const Root = styled('div')(({ theme }) => ({
    textAlign: 'right',
    paddingRight: theme.spacing(1),
}));


const Quote = styled(Root)({
    paddingRight: 8,
});

const NumberFormatter: React.FC<NumberFormatterProps> = ({
                                                             value,
                                                             renderType = 'number'
                                                         }) => {
    let displayValue;
    switch (renderType) {
        case 'currency':
            displayValue = formatCurrency(value, true);
            break;
        case 'decimal':
            displayValue = formatDecimal(value);
            break;
        default:
            displayValue = value;
    }

    if (displayValue === null || displayValue === undefined) {
        return null;
    }

    if (renderType === 'quote') {
        return <Quote>{displayValue}</Quote>;
    }

    return <Root>{displayValue}</Root>;
};

export default React.memo(NumberFormatter);
