import React from 'react';

import Typography from '@material-ui/core/Typography';
import {useSelector} from 'react-redux';
import ContentSelectors from '../../contentSelectors';
import PropTypes from 'prop-types';

VertriebswegSparteFormatter.propTypes = {
  row: PropTypes.shape({
    vertriebswegSparte: PropTypes.string
  }).isRequired
};

export default function VertriebswegSparteFormatter({row}) {
  const spartenMappings = useSelector(ContentSelectors.selectSpartenMapping);

  let spartenText = '';
  if(spartenMappings){
    spartenMappings.forEach((spartenMapping) => {
      if(spartenMapping.key === row.vertriebswegSparte){
        spartenText = spartenMapping.value;
      }
    });
  }

  return (
      <Typography color={'initial'}>
        {spartenText}
      </Typography>
  );
}