import {makeStyles} from '@material-ui/core';
import React from 'react';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles(theme => ({
  root: {
    display: 'flex',
    justifyContent: 'center'
  },
  iconWrapper: {
    '&:not(:last-child)': {
      marginRight: theme.spacing(1)
    }
  }
}));

BeziehungFormatter.propTypes = {
  row: PropTypes.shape({
    haushaltsRolle: PropTypes.string
  }).isRequired
};

export default function BeziehungFormatter({row}) {
  if(row.haushaltsRolle === 'MITGLIED'){
    return (
        <Typography color={'initial'}>
          Haushalt
        </Typography>
    );
  }

  return (
      <Typography color={'initial'}>
        {row.haushaltsRolle}
      </Typography>
  );
}