import React, {useCallback, useState} from 'react';
import {useForm} from 'react-hook-form';
import {useDispatch, useSelector} from 'react-redux';

import Widget from '../../../../components/Widget';
import {ContentActions} from '../../contentSlice';
import {makeStyles} from '@material-ui/core/styles';
import {DataTable, DataTablePagination, FilterDropdown, PushButton, ToggleSwitch} from '@cos/react-component-library';
import ContentSelectors from '../../contentSelectors';
import LoadingProgress from '@cos/react-component-library/components/spinner/LoadingProgress';
import LoadingOverlay from 'react-loading-overlay';
import Text from '@cos/react-component-library/components/text/Text';
import {ArrowBack} from '@material-ui/icons';
import {Colors} from '@cos/react-component-library/styles/theme';
import Tooltip from '@cos/react-component-library/components/tooltip/Tooltip';
import {DruckwegeMenuFormatter} from '../formatter/DruckwegeMenuFormatter';
import DruckKennzeichenEnum from '../enums/DruckKennzeichenEnum';
import {isEmpty} from '@cos/react-component-library/utils/emptyUtils';
import PropTypes from 'prop-types';
import {useTranslation} from 'react-i18next';
import Typography from '@material-ui/core/Typography';

LoadingOverlay.propTypes = undefined

const useWidgetStyles = makeStyles(() => ({
    root: {
        minHeight: '2rem',
        height: '100%',
        width: '100%'
    },
    contentWrapper: {
        padding: 0,
        margin: 0,
        height: '100%'
    },
    content: {
        padding: 0,
        margin: 0
    },
    center: {
        textAlign: 'center'
    },
    emptytext: {
        paddingTop: 16,
        fontWeight: '600'
    },
    datatable:{
        textTransform: 'none'
    },
    overlayTitle:{
        color: 'white',
        fontWeight: 'bold',
        fontSize: '2.6rem'
    }
}));

function createDokumentViewColumns(selectedDruckauftragArt, setSelectedDruckauftragArt, allDruckauftragArts, isDruckauftragSelected, t, dispatch, dokumentViewVsnr) {
    return [
        {
            id: 'reportName',
            dataField: 'reportName',
            text: 'Report-Name',
            width: 250
        },
        {
            id: 'reportBezeichnung',
            dataField: 'reportBezeichnung',
            text: 'Report-Bezeichnung',
            width: 200
        },
        {
            id: 'druckweg',
            dataField: 'druckweg',
            text: 'Druckweg',
            formatter: (row) => {
                const druckwegToLowerCase = row.druckweg.toLowerCase();
                return druckwegToLowerCase.charAt(0).toUpperCase() + druckwegToLowerCase.slice(1);
            },
            width: 250
        },
        {
            id: 'erstelltAm',
            dataField: 'erstelltAm',
            text: 'erstellt am',
            width: 250
        },
        {
            id: 'status',
            dataField: 'status',
            text: 'Status',
            formatter: (row) => {
                const statusToLowerCase = row.status.toLowerCase();
                return statusToLowerCase.charAt(0).toUpperCase() + statusToLowerCase.slice(1);
            },
            width: 250,
            renderFilter: () => (
                <FilterDropdown
                    isItemSelected={isDruckauftragSelected}
                    items={allDruckauftragArts}
                    label={'Druckauftrag-Art'}
                    selectedItems={selectedDruckauftragArt}
                    setSelectedItems={(newValue) => {
                        setSelectedDruckauftragArt(newValue);
                        dispatch(ContentActions.switch2DokumentView({
                            vsnr: dokumentViewVsnr.vsnr,
                            ladeAktuelleDruckauftraege: newValue.includes('Aktuell'),
                            ladeHistorischDruckauftraege: newValue.includes('Historisch')
                        }))
                    }}
                    tooltipClose={t('button.close')}

                />
            )
        },
        {
            id: 'typ',
            dataField: 'druckauftragTyp',
            text: 'Typ',
            width: 250,
            hidden: true
        }
    ];
}

function createTableColumns() {
    return [
        {
            id: 'vsnr',
            dataField: 'vsnr',
            text: 'VSNR',
            width: 55
        },
        {
            id: 'sparte',
            dataField: 'sparte',
            text: 'Sparte'
        },
        {
            id: 'druckweg',
            dataField: 'druckweg',
            text: 'Druckweg',
            formatter: (row) => {
                if (row.druckweg === 'N') {
                    return 'Postversand';
                } else if (row.druckweg === 'J') {
                    return 'mCD-Versand';
                }


                return row.druckweg;
            },
            width: 120,
            headerStyle: {width: '120px'}
        },
        {
            id: 'menu',
            headerStyle: {width: '100px'},
            text: '',
            formatter: <DruckwegeMenuFormatter/>
        }
    ];
}

function calcPages(itemsPerPage, arrLength) {
    if (itemsPerPage !== undefined && arrLength !== undefined) {
        return Math.ceil(arrLength / itemsPerPage) || 1;
    }
    return undefined;
}

function BackButton({onClick}) {
    return (
        <div style={{cursor: 'pointer'}}
             onClick={onClick}>
            <ArrowBack style={{color: Colors.COSMOS_BLAU}}/>
        </div>
    )
}

BackButton.propTypes = {
    onClick: PropTypes.func.isRequired
};

function evaluateDruckwegeArray(druckwege, pagesAmount, page, currentSliceEnd, currentSliceStart, pagemaxPerItem, druckwegSubArray) {
    if (druckwege) {
        if (pagesAmount && (page === pagesAmount - 1)) {
            currentSliceEnd = druckwege.length;
        } else {
            currentSliceEnd = currentSliceStart + pagemaxPerItem;
        }

        druckwegSubArray = druckwege.slice(currentSliceStart, currentSliceEnd);
    }
    return druckwegSubArray;
}

function mindestensEinVertragHatPostAlsDruckweg(druckwege) {
    for (const druckwegeElement of druckwege) {
        if (druckwegeElement.druckweg === 'N') {
            return true;
        }
    }
    return false;
}

function DruckwegWidget() {
    const {t} = useTranslation();
    const widgetClasses = useWidgetStyles();

    const {handleSubmit} = useForm();
    const dispatch = useDispatch();

    const druckwege = useSelector(ContentSelectors.selectDruckwege);
    const druckauftraege = useSelector(ContentSelectors.selectDruckauftraege);
    const saveOnlineDruckwegTempVsnr = useSelector(ContentSelectors.selectSaveOnlineDruckwegTempVsnr);
    const page = useSelector(ContentSelectors.selectCurrentPage);
    const showDokumentView = useSelector(ContentSelectors.selectShowDokumentView);
    const loadingDokumentView = useSelector(ContentSelectors.selectLoadingDokumentView);
    const ladeDruckwege = useSelector(ContentSelectors.selectLadeDruckwege);
    const dokumentViewVsnr = useSelector(ContentSelectors.selectDokumentViewVsnr);
    const switchValue = useSelector(ContentSelectors.selectDruckKennzeichenSwitchValue);
    const saveOnlineDruckwegOngoing = useSelector(ContentSelectors.selectSaveOnlineDruckwegOngoing);

    const [selectedDruckauftragArt, setSelectedDruckauftragArt] = useState(['Historisch']);
    const [allDruckauftragArts, setAllDruckauftragArts] = useState(['Aktuell', 'Historisch']);

    const isDruckauftragSelected = useCallback(druckauftragArt => {
        return selectedDruckauftragArt && selectedDruckauftragArt.includes(druckauftragArt);
    }, [selectedDruckauftragArt]);

    let druckwegColumns = createTableColumns();
    let dokumentViewColumns = createDokumentViewColumns(selectedDruckauftragArt, setSelectedDruckauftragArt, allDruckauftragArts, isDruckauftragSelected, t, dispatch, dokumentViewVsnr);

    const onSubmit = useCallback((formValues) => {
        dispatch(ContentActions.suche(formValues));
    }, [dispatch]);

    const backToContractView = useCallback((formValues) => {
        dispatch(ContentActions.switch2ContractView(formValues));
    }, [dispatch]);

    const onDruckKennzeichenSwitchClicked = filterValue => {
        console.log('Aendern des Druckkennzeichens auf: ' + filterValue);
        dispatch(ContentActions.onDruckKennzeichenSwitchClicked(filterValue));
    };

    const pagemaxPerItem = 5;
    const pagesAmount = calcPages(pagemaxPerItem, druckwege?.length);
    const currentSliceStart = page * pagemaxPerItem;
    let currentSliceEnd = 0;

    let druckwegSubArray = [];
    druckwegSubArray = evaluateDruckwegeArray(druckwege, pagesAmount, page, currentSliceEnd, currentSliceStart, pagemaxPerItem, druckwegSubArray);

    const handleChangePage = (event, newPage) => {
        console.log('handleChange');

        dispatch(ContentActions.setCurrentPage(newPage));
    };

    const handleChangeRowsPerPage = event => {
        console.log('HandleChangeRowsPerPage');
    };

    const saveOfflineDruckweg = useCallback((vsnr) => {
        dispatch(ContentActions.saveOfflineDruckweg(vsnr))
    }, [dispatch, ContentActions]);

    const saveOfflineDruckwegTemp = useCallback((vsnr) => {
        dispatch(ContentActions.saveOfflineDruckwegTemp(vsnr))
    }, [dispatch, ContentActions]);

    let disableToggleSwitchButton = false;
    let toggleSwitchButtonValue = switchValue;
    if(!isEmpty(druckwege)) {
        let mindestensEinVertragHatPostweg = mindestensEinVertragHatPostAlsDruckweg(druckwege);

        toggleSwitchButtonValue = mindestensEinVertragHatPostweg ? 'nein' : 'ja';
    }

    if(saveOnlineDruckwegTempVsnr){
        disableToggleSwitchButton = true;
    }

    const toolbarRenderer = () => {
        return (
                <div style={{display: 'flex', alignItems: 'center', justifyContent: 'end', width: '100%'}}>
                    <Text value={'Dokumente zum Vertrag Online erhalten'} style={{paddingLeft: 8, paddingRight: 12}}/>

                    {!saveOnlineDruckwegOngoing &&
                        <ToggleSwitch
                            value={toggleSwitchButtonValue}
                            onChange={newValue => onDruckKennzeichenSwitchClicked(newValue)}
                            onValue={DruckKennzeichenEnum.JA}
                            offValue={DruckKennzeichenEnum.NEIN}
                            onLabel={DruckKennzeichenEnum.labelOf(DruckKennzeichenEnum.JA)}
                            offLabel={DruckKennzeichenEnum.labelOf(DruckKennzeichenEnum.NEIN)}
                            enumType={DruckKennzeichenEnum}
                            disabled={disableToggleSwitchButton}
                        />
                    }
                    {saveOnlineDruckwegOngoing &&
                        <div style={{paddingRight: '28px', paddingLeft: '28px'}}>
                            <LoadingProgress size={22} />
                        </div>
                    }
                </div>
        );
    };

    return (
        <Widget classes={widgetClasses} title="Druckweg" toolbarRenderer={toolbarRenderer}>
            <LoadingOverlay
                active={saveOnlineDruckwegTempVsnr}
                text= {
                    <div style={{display: 'flex',
                        flexDirection: 'column',
                        textAlign: 'center',
                        width: '100%'
                    }}>
                        <Typography
                            className={widgetClasses.overlayTitle}
                            variant="h1"
                            noWrap
                        >
                            {'Druckweg für Vertrag ' + saveOnlineDruckwegTempVsnr + ' wirklich ändern?'}
                        </Typography>

                        <div style={{display: 'flex',
                            justifyContent: 'center',
                            textAlign: 'center',
                            paddingTop:10,
                            width: '100%'
                        }}>
                            <PushButton
                                title={'Abbrechen'}
                                text={'Abbrechen'}
                                severity={'info'}
                                style={{color: Colors.COSMOS_BLAU, marginRight:10, height:30, fontWeight: 800}}
                                onClick={() => saveOfflineDruckwegTemp(null)}
                            />

                            <PushButton
                                title={'Auf Postversand umstellen'}
                                text={'OK'}
                                style={{color: Colors.COSMOS_BLAU, marginRight:10, height:30, fontWeight: 800}}
                                onClick={() => saveOfflineDruckweg(saveOnlineDruckwegTempVsnr)}
                            />
                        </div>
                    </div>
                }
                styles={{
                    overlay: (base) => ({
                        ...base,
                        background: Colors.COSMOS_BLAU_OPACITY(0.3),
                        fontSize: '2.0rem',
                        fontWeight: 800
                    }),
                    wrapper: {
                        display: 'contents',
                        flexGrow: 'inherit',
                        position: 'fixed', /* Stay in place */
                        zIndex: 999 /* Sit on top */
                    }
                }}
            >
                <form onSubmit={handleSubmit(onSubmit)} style={{
                    height: '100%'
                }}>
                    {(ladeDruckwege && !showDokumentView) &&
                        <div>
                            <LoadingProgress/>
                            <Text className={widgetClasses.center} value={'wird geladen...'}/>
                        </div>
                    }

                    {(!ladeDruckwege && !showDokumentView && !saveOnlineDruckwegOngoing) &&
                        <div style={{
                            height: '95%',
                            paddingTop: 16,
                            paddingLeft: 8,
                            paddingRight: 4,
                            overflowX: 'scroll',
                            overflowY: 'scroll'
                        }}>
                            <DataTable
                                rows={druckwegSubArray}
                                columns={druckwegColumns}
                                data-testid={'druckweg-table'}
                            />

                            <DataTablePagination
                                component="div"
                                count={druckwege && druckwege.length}
                                colSpan={druckwegColumns.length}
                                rowsPerPage={5}
                                page={page}
                                onChangePage={handleChangePage}
                                onChangeRowsPerPage={handleChangeRowsPerPage}>
                            </DataTablePagination>
                        </div>
                    }

                    {(showDokumentView) &&
                        <div >
                            <div style={{display: 'flex',
                                height: '95%',
                                paddingTop: 16,
                                paddingLeft: 8,
                                paddingRight: 4,
                                overflowX: 'scroll',
                                overflowY: 'scroll'
                            }}>
                                <Tooltip title={'Zurück zur Übersicht'}>
                                    <BackButton onClick={() => backToContractView()}/>
                                </Tooltip>
                                <Text value={'Dokumente zu Vertrag ' + dokumentViewVsnr.vsnr} style={{padding: 2}}/>
                            </div>

                            {!loadingDokumentView &&
                                <div style={{
                                    paddingLeft: 8,
                                    paddingRight: 8
                                }}>

                                    <DataTable
                                        rows={druckauftraege}
                                        columns={dokumentViewColumns}
                                        className={widgetClasses.dataTable}
                                    />

                                    {isEmpty(druckauftraege) &&
                                        <strong>
                                            <Text value={'Es wurden keine Druckaufträge gefunden.'} className={widgetClasses.emptytext}/>
                                        </strong>
                                    }
                                </div>
                            }

                            {loadingDokumentView &&
                                <div>
                                    <LoadingProgress/>
                                    <Text className={widgetClasses.center} value={'Druckaufträge werden geladen...'}/>
                                </div>
                            }
                        </div>
                    }
                </form>
            </LoadingOverlay>
        </Widget>

    );
}

export default DruckwegWidget;
