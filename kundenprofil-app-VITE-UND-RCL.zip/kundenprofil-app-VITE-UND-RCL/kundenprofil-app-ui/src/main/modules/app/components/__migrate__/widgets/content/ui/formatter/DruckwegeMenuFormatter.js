import {makeStyles} from '@material-ui/core';
import React, {useCallback} from 'react';
import {ContentActions} from '../../contentSlice';
import {useDispatch, useSelector} from 'react-redux';
import Tooltip from '@cos/react-component-library/components/tooltip/Tooltip';
import {Colors} from '@cos/react-component-library/styles/theme';
import {EditIcon} from '@cos/react-component-library/components/icons/generated/EditIcon';
import {PushButton, ToggleButtons} from '@cos/react-component-library';
import ContentSelectors from '../../contentSelectors';
import LoadingProgress from '@cos/react-component-library/components/spinner/LoadingProgress';
import Text from '@cos/react-component-library/components/text/Text';
import DruckwegFilterEnum from '../enums/DruckwegFilterEnum';
import {AlternateEmail, MailOutline, OpenInBrowser} from '@material-ui/icons';


const useStyles = makeStyles(theme => ({
  actionColumn: {
    display: 'flex',
    justifyContent: 'flex-end',
    paddingLeft: 2
  },
  actionColumnItem: {
    '&:not(:last-child)': {
      margin: theme.spacing(1)
    }
  },
  button:{
    padding: 1,
    borderStyle: 'outset',
    borderWidth: 'initial',
    backgroundColor: Colors.COSMOS_HELLBLAU,
    borderColor: Colors.COSMOS_HELLBLAU,
    '&:hover': {
      background: Colors.COSMOS_GRUEN
    },
    '&:last-child': {
      borderRight: 'solid 1px #cccccc'
    }
  },
  offlinebutton:{
    padding: 4,
    borderStyle: 'outset',
    borderWidth: 'initial',
    background: Colors.COSMOS_GRAU,
    color: Colors.COSMOS_BLAU,
    textTransform: 'none',
    '&:hover': {
      background: Colors.COSMOS_GRAU_HELLER
    },
    '&:last-child': {
      borderRight: 'solid 1px #cccccc'
    }
  },
  toggleButtons: {
    paddingBottom: '0px',
    paddingTop: '0px',
    paddingRight: '8px',
    fontWeight: 'normal',
    textTransform: 'none',
    '& > .MuiToggleButton-root.Mui-selected': {
      textTransform: 'none',
      fontSize: '1.0rem'
    },
    '& > .MuiToggleButton-root': {
      textTransform: 'none',
      fontSize: '1.0rem'
    }
  }
}));

function createOnlineOfflineToggleButton(saveOnlineDruckweg, row, classes, saveOfflineDruckweg, showDokumentView) {
  const druckwegValue = row.druckweg === 'J' ? DruckwegFilterEnum.ONLINE : DruckwegFilterEnum.OFFLINE;

  return <div style={{
    display: 'flex',
    textAlign: 'center'
  }}>

    <ToggleButtons
        data-testid={'druckweg-filter-buttons'}
        enumType={DruckwegFilterEnum}
        labelFormatter={entry => <Text value={entry.label}/>}
        onChange={newValue => {
          if(newValue === DruckwegFilterEnum.ONLINE) {
            saveOnlineDruckweg(row.vsnr);
          }

          if(newValue === DruckwegFilterEnum.OFFLINE) {
            saveOfflineDruckweg(row.vsnr);
          }
        }}
        value={druckwegValue}
        className={classes.toggleButtons}
    />

    <PushButton
        title={'Details'}
        icon={<OpenInBrowser style={{color: Colors.COSMOS_GRAU_DARKER, paddingLeft: 2, paddingTop: 2}}/>}
        onClick={() => showDokumentView(row.vsnr)}
    />
  </div>;
}

export function DruckwegeMenuFormatter({row}) {
  const classes = useStyles();
  const dispatch = useDispatch();

  const editVsnr = useSelector(ContentSelectors.selectEditVsnr);
  const saveOnlineDruckwegOngoing = useSelector(ContentSelectors.selectSaveOnlineDruckwegOngoing);

  const showDokumentView = useCallback((vsnr) => {
    dispatch(ContentActions.switch2DokumentView({
      vsnr: vsnr,
      ladeAktuelleDruckauftraege: false,
      ladeHistorischDruckauftraege: true
    }))
  }, [dispatch, ContentActions]);

  const saveOfflineDruckweg = useCallback((vsnr) => {
    dispatch(ContentActions.saveOfflineDruckweg(vsnr))
  }, [dispatch, ContentActions]);

  const saveOfflineDruckwegTemp = useCallback((vsnr) => {
    dispatch(ContentActions.saveOfflineDruckwegTemp(vsnr))
  }, [dispatch, ContentActions]);

  const saveOnlineDruckweg = useCallback((vsnr) => {
    dispatch(ContentActions.saveOnlineDruckweg(vsnr))
  }, [dispatch, ContentActions]);

  const title = 'Kundenprofil für ' + row.vorname + ' laden';

  return (
      <div className={classes.actionColumn}>
        {(editVsnr === row.vsnr) &&
            <div style={{display: 'flex',
              textAlign: 'center',
              flexDirection: 'row',
              justifyContent: 'space-between'
            }}>

              {saveOnlineDruckwegOngoing &&
                  <div>
                    <LoadingProgress/>
                    <Text value={'wird gespeichert...'}/>
                  </div>
                }

              {!saveOnlineDruckwegOngoing &&
                  createOnlineOfflineToggleButton(saveOnlineDruckweg, row, classes, saveOfflineDruckweg, showDokumentView)
              }
            </div>
        }

        {(editVsnr !== row.vsnr) &&
            <div style={{display: 'flex',
              textAlign: 'center',
              width: '100%'
            }}>
              <Tooltip title={title}>
                {row.druckweg === 'J' ? (
                  <PushButton
                    title={'Auf Postversand umstellen'}
                    icon={<MailOutline style={{color: Colors.COSMOS_BLAU}}/>}
                    onClick={() => saveOfflineDruckwegTemp(row.vsnr)}
                  />
                ) : (
                  <PushButton
                    title={'Auf mCD-Versand umstellen'}
                    icon={<AlternateEmail style={{color: Colors.COSMOS_BLAU}}/>}
                    onClick={() => saveOnlineDruckweg(row.vsnr)}
                  />
                )}
              </Tooltip>
            </div>
        }

        {(editVsnr !== row.vsnr) &&
            <div style={{display: 'flex',
              textAlign: 'center',
              justifyContent: 'flex-end',
              width: '100%'
            }}>

              <Tooltip title={title}>
                <PushButton
                    title={'Details'}
                    icon={<OpenInBrowser style={{color: Colors.COSMOS_GRAU_DARKER}}/>}
                    onClick={() => showDokumentView(row.vsnr)}
                />
              </Tooltip>
            </div>
        }
      </div>
  )
}
