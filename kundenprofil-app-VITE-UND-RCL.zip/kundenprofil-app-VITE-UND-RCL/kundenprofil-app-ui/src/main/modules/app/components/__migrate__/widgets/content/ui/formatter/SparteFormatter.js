import React from 'react';

import Typography from '@material-ui/core/Typography';
import {useSelector} from 'react-redux';
import ContentSelectors from '../../contentSelectors';
import PropTypes from 'prop-types';
import {isEmpty} from '@cos/react-component-library/utils/emptyUtils';

SparteFormatter.propTypes = {
  row: PropTypes.shape({
    sparte: PropTypes.string
  }).isRequired
};

export default function SparteFormatter({row}) {
  const spartenMappings = useSelector(ContentSelectors.selectSpartenMapping);

  let spartenText = '';
  if(spartenMappings){
    spartenMappings.forEach((spartenMapping) => {
      if(spartenMapping.key === row.sparte){
        spartenText = spartenMapping.value;
      }
    });

    if(isEmpty(spartenText)){
        spartenText = 'Tagesgeld';
    }
  }

  return (
      <Typography color={'initial'}>
        {spartenText}
      </Typography>
  );
}