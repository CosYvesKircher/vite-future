import AppErrorDialog from '@cos/react-component-library/components/dialog/AppErrorDialog';
import {Colors} from '@cos/react-component-library/styles/theme';
import Logger from '@cos/react-component-library/utils/Logger';
import {makeStyles} from '@material-ui/core/styles';
import clsx from 'clsx';
import React from 'react';
import {useTranslation} from 'react-i18next';

import ErrorHint from '../../components/ErrorHint/ErrorHint';
import LoadingHint from '../../components/LoadingHint/LoadingHint';
import MainAppBar from '../../components/MainAppBar/MainAppBar';
import {REMOTE_STATE} from '../../utils/rest/restUtils';
import ErstvertragWidget from '../content/ui/widgets/ErstvertragWidget';
import PartnerdatenWidget from '../content/ui/widgets/PartnerdatenWidget';
import KundenprofilWidget from '../content/ui/widgets/KundenprofilWidget';
import DruckwegWidget from '../content/ui/widgets/DruckwegWidget';
import PropTypes from 'prop-types';

const useStyles = makeStyles((theme) => ({
  main: {
    display: 'block',
    paddingTop: theme.spacing(1),
    paddingBottom: theme.spacing(1),
    paddingRight: theme.spacing(1),
    paddingLeft: theme.spacing(1),
    width: '100%',
    height: 'calc(100vh - 50px)' // 50px = HEIGHT OF MainAppBar
  },
  gridContainer: {
    display: 'grid',
    gridTemplateRows: '220px 200px calc(100vh - 500px)',
    gridTemplateColumns: 'minmax(500px,40%) auto',
    gridTemplateAreas: ['"partnerdaten kundenprofil"', '"vetriebsweg kundenprofil"', '"druckweg kundenprofil"'].join(' '),
    gridColumnGap: 5,
    gridRowGap: 5,
    height: '100%',
    width: '100%',
    overflowY: 'hidden'
  },
  gridItem: {
    overflow: 'auto'
  },
  partnerdaten: {
    gridArea: 'partnerdaten'
  },
  kundenprofil: {
    gridArea: 'kundenprofil'
  },
  druckweg: {
    gridArea: 'druckweg'
  },
  vetriebsweg: {
    gridArea: 'vetriebsweg',
    backgroundColor: Colors.COSMOS_INPUT_BACKGROUND_FILLED,
    overflow: 'auto'
  }
}));

function AppUI({remoteState, remoteError = null, userCanOpenApp = true}) {
  const classes = useStyles();
  const {t} = useTranslation();

  if (remoteState === REMOTE_STATE.NOT_LOADED) {
    return null;
  }

  if (remoteState === REMOTE_STATE.LOADING) {
    return <LoadingHint loadingText="app.loading" />;
  }

  if (remoteState === REMOTE_STATE.ERROR) {
    Logger.error('Fehler beim Laden der App: ', remoteError);
    return <AppErrorDialog />;
  }

  return (
    <div className={classes.flexWrapper}>
      <MainAppBar/>
      {!userCanOpenApp ? (
          <>
            <ErrorHint
                error={t('app.error.nichtberechtigt')}
                hideErrorPrefix
            />
          </>
      ) : (
        <main className={classes.main}>
          <div className={classes.gridContainer}>
            <div
              className={clsx(classes.gridItem, classes.partnerdaten)}
              data-testid="app-grid-partnerdaten"
            >
              <PartnerdatenWidget/>
            </div>
            <div
              className={clsx(classes.gridItem, classes.vetriebsweg)}
              data-testid="app-grid-vetriebsweg"
            >
              <ErstvertragWidget/>
            </div>
            <div
              className={clsx(classes.gridItem, classes.druckweg)}
              data-testid="app-grid-druckweg"
            >
              <DruckwegWidget/>
            </div>
            <div
              className={clsx(classes.gridItem, classes.kundenprofil)}
              data-testid="app-grid-kundenprofil"
            >
              <KundenprofilWidget/>
            </div>
          </div>
        </main>
      )}
    </div>
  );
}

AppUI.propTypes = {
  remoteState: PropTypes.string.isRequired,
  remoteError: PropTypes.any,
  userCanOpenApp: PropTypes.bool
};

export default AppUI;
