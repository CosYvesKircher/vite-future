import {Box, Grid} from "@mui/material";
import React from "react";
import {useSelector} from "react-redux";
import {selectContentKundenprofil} from "../../../store/content/ContentSelector";
import Typography from "@mui/material/Typography";
import {DataTable} from "@cos/rcl-future/components";
import {styled } from '@mui/material/styles';

import {formatCurrency} from "../../../utils/NumberUtils";
import NumberFormatter from "./formatter/NumberFormatter";
import {Colors} from "@cos/rcl-future/theme";
import {Vertriebsweg} from "../../../../API-GEN/kundenprofil-app";
import VertriebswegSparteFormatter from "./formatter/VertriebswegSparteFormatter";

type RentabilitaetRow = {
    id: number;
    sparte: string;
    anzahl?: string;
    summe?: string;
};

const GridHeadline = styled(Grid)({
    backgroundColor: Colors.COSMOS_APP_BACKGROUND,

});

function WirtschaftlichkeitPanel() {

    const kundenprofil = useSelector(selectContentKundenprofil);

    const columnsRentablitaet =
        [
            {
                id: 'sparte',
                dataField: 'sparte',
                text: 'Sparte',
                headerStyle: {width: 250}
            },
            {
                id: 'anzahl',
                align: 'center',
                dataField: 'anzahl',
                text: 'Anzahl',
                headerStyle: {width: 100}
            },
            {
                id: 'summe',
                dataField: 'summe',
                text: 'Summe',
                headerStyle: {width: 200},
                formatter: (params: RentabilitaetRow) => <VertriebswegSparteFormatter vertriebswegsparteKey={params.sparte} />
            }
        ];

    const rowsRentablitaet: RentabilitaetRow[] = [
        {
            id: 1,
            sparte: 'Leistung Leben',
            anzahl: kundenprofil?.kundenprofilRentabilitaetGesamt?.anzahlLeistung,
            summe: kundenprofil?.kundenprofilRentabilitaetGesamt?.summeLeistung
        },
        {
            id: 2,
            sparte: 'Schaden Komposit',
            anzahl: kundenprofil?.kundenprofilRentabilitaetGesamt?.anzahlSchaden,
            summe: kundenprofil?.kundenprofilRentabilitaetGesamt?.summeSchaden
        }
    ];


    return <>
        <Grid size={{ xs: 12}}>
            <Typography
                color="textPrimary"
                variant="h3"
            >
                Wirtschaftlichkeit/Rentabilität
            </Typography>
        </Grid>
        <Grid size={{ xs: 8}}>
            <DataTable
                rows={rowsRentablitaet}
                columns={columnsRentablitaet}
                // className={contentClasses.dataTable}
            />
        </Grid>
        <Grid size={{ xs: 4}}>
            <Grid container spacing={1} style={{ paddingLeft: 4 }}>
                <GridHeadline size={{ xs: 12}}>
                    <Typography
                        color="textPrimary"
                        variant="h6"
                        fontWeight="bold"
                    >
                        Gesamtbetrag:
                    </Typography>
                </GridHeadline>

                <Grid size={{ xs: 12}}>
                    {formatCurrency(kundenprofil?.kundenprofilRentabilitaetGesamt?.gesamtJahresBeitrag)}
                </Grid>
                <GridHeadline size={{ xs: 12}}>
                    <Typography
                        color="textPrimary"
                        variant="h6"
                        fontWeight="bold"
                    >
                        Komposit-Schadenquote:
                    </Typography>
                </GridHeadline>
                <Grid size={{ xs: 12}}>
                    {kundenprofil?.kundenprofilRentabilitaetGesamt?.kompositSchadenquote}
                </Grid>
            </Grid>
        </Grid>
    </>;
}
export default WirtschaftlichkeitPanel;