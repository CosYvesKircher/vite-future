import React from 'react';

interface BeziehungFormatterProps {
    haushaltsRolle: string;
}

const BeziehungFormatter: React.FC<BeziehungFormatterProps> = ({ haushaltsRolle }) => {
    if (haushaltsRolle === 'MITGLIED') {
        return <>Haushalt</>;
    }

    return <>{haushaltsRolle}</>;
};

export default BeziehungFormatter;
