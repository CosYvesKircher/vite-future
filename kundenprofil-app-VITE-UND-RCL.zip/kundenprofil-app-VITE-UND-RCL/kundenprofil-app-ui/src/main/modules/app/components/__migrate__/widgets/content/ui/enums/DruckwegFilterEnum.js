import {createEnum} from '../../../../utils/enum/enum';

const DruckwegFilterEnum = createEnum('DruckwegFilterEnum', {
  ONLINE: {
    value: 'ONLINE',
    label: 'Online'
  },
  OFFLINE: {
    value: 'OFFLINE',
    label: 'offline'
  }
});

export default DruckwegFilterEnum;
