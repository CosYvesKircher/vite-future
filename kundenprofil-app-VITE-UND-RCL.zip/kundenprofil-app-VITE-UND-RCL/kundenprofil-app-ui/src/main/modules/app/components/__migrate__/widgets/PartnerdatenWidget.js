
import React, {Fragment} from 'react';
import {useSelector} from 'react-redux';

import Widget from '../../../../components/Widget';
// import {REMOTE_STATE} from '../../../../utils/rest/restUtils';
import ContentSelectors from '../../contentSelectors';
import {makeStyles} from '@material-ui/core/styles';
import LoadingProgress from '@cos/react-component-library/components/spinner/LoadingProgress';
import Text from '@cos/react-component-library/components/text/Text';
import {Grid, Typography} from '@material-ui/core';


const useWidgetStyles = makeStyles({
    root: {
        display: 'flex',
        flexDirection: 'column',
        paddingTop: 5,
        margin: 0,
        overflow: 'hidden',
        height: '100%',
        width: '100%'
    },
    contentWrapper: {
        padding: 0,
        margin: 0,
        height: '100%'
    },
    content: {
        padding: 0,
        margin: 0
    }
});

const useContentStyles = makeStyles(() => ({
    contentArea: {
        padding: 0,
        margin: 0,
        display: 'flex'
    },
    area: {
        paddingTop: 16,
        paddingLeft: 10
    },
    label: {
        paddingTop: 0,
        fontWeight: '600'
    },
    gridItem: {
        padding: '0.5rem 1rem'
    },
    center: {
        textAlign: 'center'
    }
}));

function joinNonEmptyParts(parts) {
    return parts.filter(s => s !== '' && s !== undefined).join(' ');
}

function findKOWAnschlussByArt(kowArt, kommunikationswege) {
    if(kowArt === 'E-MAIL'){
        return kommunikationswege?.find(kow => kow.kommunikationsWegArt === 'EMAIL')?.anschluss;
    }
    return kommunikationswege?.find(kow => kow.kommunikationsWegArt === kowArt)?.anschluss;
}

function bestimmePartnerTitel(partner) {
    if (partner.titel !== 'KEIN_TITEL') {
        return joinNonEmptyParts([
            partner.anrede,
            partner.titel
        ]);
    }

    return partner.anrede;
}

function createPartnerPanel(contentClasses, partner, kundenprofil, kommunikationswege){
    const hauptWohnsitz = partner.adressen.find((adresse) => adresse.adressTyp === 'HAUPTWOHNSITZ');

    return (
        <Grid className={contentClasses.contentArea}>
                <Grid className={contentClasses.area} container item xs={6}>
                        <Typography component="div">
                            <strong>
                                {bestimmePartnerTitel(partner)}
                            </strong>
                            <br />
                            <strong>
                                {joinNonEmptyParts([
                                    partner.vorname,
                                    partner.name
                                ])}
                            </strong>
                            <br />
                            <Fragment>
                                {hauptWohnsitz?.zusatz}
                                <br />
                                {hauptWohnsitz?.strasse} {hauptWohnsitz?.hausnummer}
                                <br />
                                {hauptWohnsitz?.plz} {hauptWohnsitz?.ort}
                            </Fragment>
                            <br />
                            <br />
                            <strong>Geb.: </strong>
                            {partner.geburtsDatum}
                        </Typography>
                </Grid>

                <Grid container item xs={6}>
                    <Typography component="div">
                        <br/>
                        <Fragment>
                            <strong>Tel.:</strong>{' '}
                            {findKOWAnschlussByArt(KowArtEnum.TELEFON, kommunikationswege) ??
                              findKOWAnschlussByArt(KowArtEnum.MOBILFUNK, kommunikationswege)}
                            <br/>
                            <strong>E-Mail:</strong> {findKOWAnschlussByArt(KowArtEnum.E_MAIL, kommunikationswege)?.toLocaleLowerCase()}
                        </Fragment>
                        <br/>
                        <br/>
                        <strong>Beruf: </strong>
                        {partner.berufBezeichnung}
                        <br/>
                        <strong>Beschäftigungsverhältnis: </strong>
                        {partner.beschaeftigungsverh}
                    </Typography>
                </Grid>
        </Grid>
    );
}

function PartnerdatenWidget() {
    const widgetClasses = useWidgetStyles();
    const contentClasses = useContentStyles();
    const {remoteState} = useSelector(ContentSelectors.selectRemoteState);
    const partner = useSelector(ContentSelectors.selectPartner);
    const kundenprofil = useSelector(ContentSelectors.selectKundenprofil);
    const kommunikationswege = useSelector(ContentSelectors.selectKommunikationswege);

    if (remoteState === REMOTE_STATE.LOADED && kundenprofil) {
        const fullName = 'Kundenprofil von ' + partner.vorname + ' ' + partner.name;

        return (
            <Widget classes={widgetClasses} title={fullName}>
                {createPartnerPanel(contentClasses, partner, kundenprofil, kommunikationswege)}
            </Widget>
        );
    } else if (remoteState === REMOTE_STATE.ERROR) {
        return (
            <Widget classes={widgetClasses} title={'Kundenprofil'}>
                Fehler beim Laden der Partnerdaten!
            </Widget>
        );
    } else {
        return (
            <Widget classes={widgetClasses}>
                <div>
                    <LoadingProgress/>
                    <Text className={contentClasses.center} value={'wird geladen...'}/>
                </div>
            </Widget>
        );
    }
}

export default PartnerdatenWidget;
