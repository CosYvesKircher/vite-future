import React, {useState} from 'react';
import {useSelector} from "react-redux";
import {selectContentHaushaltspartner, selectContentKundenprofil, selectPartnerErweiterterHaushalt} from "../../../store/content/ContentSelector";


import {Partner} from "../../../api/interfaces/Partner.interface";
import NameFormatter from "./formatter/NameFormatter";
import BeziehungFormatter from "./formatter/BeziehungFormatter";
import Typography from "@mui/material/Typography";
import {Checkbox, FormControlLabel, Grid } from "@mui/material";
import {DataTable} from "@cos/rcl-future/components";
import {styled} from "@mui/material/styles";
import {Colors} from "@cos/rcl-future/theme";

//TODO
// zahlungsmorallabel: {
//     backgroundColor: Colors.COSMOS_BLAU_HELLER_5,
//         padding: '2px 10px 2px 5px',
//         fontWeight: '600'
// },


// TODO: Auslagern wird an mehreren stellen verwendet
const GridHeadline = styled(Grid)({
    backgroundColor: Colors.COSMOS_APP_BACKGROUND
});

function PartnerPanel() {

    const kundenprofil = useSelector(selectContentKundenprofil);
    const haushaltsPartner = useSelector(selectContentHaushaltspartner);
    const haushaltErweitert = useSelector(selectPartnerErweiterterHaushalt);

    const [zeigeErweitertenHaushalt, setZeigeErweitertenHaushalt] = useState(false);

    // TODO refactor
    let anspruchsteller = 0;
    let empfehler = 0;
    let kundenbeschwerden = 0;
    if(kundenprofil?.besondereRollen){
        kundenprofil?.besondereRollen.forEach((rolle) => {
            if(rolle.rolle === 'AS'){
                anspruchsteller++;
            }
            if(rolle.rolle === 'EMP'){
                empfehler++;
            }
        });
    }
    // TODO refactor
    if(kundenprofil?.beschwerdeListeEintrag){
        kundenprofil?.beschwerdeListeEintrag.forEach((beschwerde) => {
            kundenbeschwerden++;
        });
    }

    const columnsPartner =
        [
            {
                id: 'name',
                dataField: 'name',
                text: 'Name',
                formatter: (row: Partner)=>  <NameFormatter vorname={row.vorname ? row.vorname : ''} name={row.name ? row.name : ''}  />,
                headerStyle: {width: 250}
            },
            {
                id: 'geburtsDatum',
                dataField: 'geburtsDatum',
                text: 'Geburtsdatum',
                headerStyle: {width: 150}
            },
            {
                id: 'beziehung',
                dataField: 'haushaltsRolle',
                text: 'Beziehung',
                formatter: (row: Partner)=>  <BeziehungFormatter haushaltsRolle={row.haushaltsRolle ? row.haushaltsRolle : ''}  />,
                headerStyle: {width: 150}
            }
        ];
    const columnsErweiterterPartnerHaushalt =
        [
            {
                id: 'name',
                dataField: 'name',
                text: 'Name',
                formatter: (row: Partner)=>  <NameFormatter vorname={row.vorname ? row.vorname : ''} name={row.name ? row.name : ''}  />,
                headerStyle: {width: 250}
            },
            {
                id: 'geburtsDatum',
                dataField: 'geburtsDatum',
                text: 'Geburtsdatum',
                headerStyle: {width: 150}
            },
            {
                id: 'beziehung',
                dataField: 'haushaltsRolle',
                text: 'Beziehung',
                formatter: (row: Partner) => {
                    return 'Erweitert';
                },
                headerStyle: {width: 150}
            }
        ];

    return (
        <>
            <Grid size={{ xs: 12}} style={{marginBottom: 4}}>
                <div style={{display: 'flex'}}>
                    <Typography
                        color="textPrimary"
                        variant="h3"
                        // className="headlineTitle"
                    >
                        Partner
                    </Typography>
                    <div style={{display: 'flex', width: '100%', justifyContent: 'flex-end'}}>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    style={{padding: 0}}
                                    size="small"
                                    checked={zeigeErweitertenHaushalt}
                                    onChange={(_, checked) => setZeigeErweitertenHaushalt(checked)}
                                />
                            }
                            label="Erweiterter Haushalt anzeigen"
                        />
                    </div>
                </div>
            </Grid>
            <Grid size={{ xs: 8}}>
                <Grid container spacing={1}>
                    <Grid size={{ xs: 12}}>
                        <DataTable
                            rows={haushaltsPartner}
                            columns={columnsPartner}
                            emptyPanel={"Keine Haushaltspartner vorhanden."}
                            // className={contentClasses.dataTable}
                        />
                    </Grid>
                    {zeigeErweitertenHaushalt && (
                        <Grid size={{ xs: 12}}>
                            <DataTable
                                rows={haushaltErweitert}
                                columns={columnsErweiterterPartnerHaushalt}
                                emptyPanel={"Kein erweiterter Haushaltspartner vorhanden."}
                                // className={contentClasses.dataTable}
                            />
                        </Grid>
                    )}
                </Grid>

            </Grid>
            <Grid size={{ xs: 4}}>
                <Grid container spacing={1}>
                    <GridHeadline size={{ xs: 12}}>
                        <Typography
                            color="textPrimary"
                            variant="h6"
                            fontWeight="bold"
                        >
                            Kundenbeschwerden:
                        </Typography>
                    </GridHeadline>
                    <Grid size={{ xs: 12}}>
                        {kundenbeschwerden}
                    </Grid>

                    <GridHeadline size={{ xs: 12}}>
                        <Typography
                            color="textPrimary"
                            variant="h6"
                            fontWeight="bold"
                        >
                            Anspruchssteller:
                        </Typography>
                    </GridHeadline>
                    <Grid size={{ xs: 12}}>
                        {anspruchsteller}
                    </Grid>

                    <GridHeadline size={{ xs: 12}}>
                        <Typography
                            color="textPrimary"
                            variant="h6"
                            fontWeight="bold"
                        >
                            Empfehler:
                        </Typography>
                    </GridHeadline>
                    <Grid size={{ xs: 12}}>
                        {empfehler}
                    </Grid>
                </Grid>

            </Grid>
        </>);
}

export default PartnerPanel;