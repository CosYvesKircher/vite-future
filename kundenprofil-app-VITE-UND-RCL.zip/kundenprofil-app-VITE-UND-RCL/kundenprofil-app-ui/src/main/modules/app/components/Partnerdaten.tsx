import React, {Fragment} from 'react';
import {useSelector} from "react-redux";
import {Grid} from "@mui/material";
import Widget from "../../../components/Widget";

import KowArtEnum from "./enums/KowArtEnum";
import {Partner} from "../../../api/interfaces/Partner.interface";
import {selectContentPartner, selectKommunikationswege} from "../../../store/content/ContentSelector";
import {Kommunikationsweg} from "../../../../API-GEN/partner-ermitteln-bas";
import {KommunikationsWeg} from "../../../../API-GEN/partner-haushalt-verwalten-bas";

function joinNonEmptyParts(parts: (string | undefined)[]) {
    return parts.filter(s => s !== '' && s !== undefined).join(' ');
}

// function findKOWAnschlussByArt(kowArt: KowArtEnum, partner: Partner) {
//     return partner.kommunikationswege?.find(kow => kow.kommunikationsWegArt === kowArt)?.anschluss;
// }

function bestimmePartnerTitel(partner: Partner) {
    if (partner.titel !== 'KEIN_TITEL') {
        return joinNonEmptyParts([
            partner.anrede,
            partner.titel
        ]);
    }
    return partner.anrede;
}

function getHauptWohnsitz(partner: Partner){
    return partner.adressen?.find((adresse) => adresse.adressTyp === 'HAUPTWOHNSITZ');
}

function findKOWAnschlussByArt(kowArt: KowArtEnum, kommunikationswege: KommunikationsWeg[]) {
    if(kowArt === 'E-Mail'){
        return kommunikationswege?.find(kow => kow.kommunikationsWegArt === 'EMAIL')?.anschluss;
    }
    return kommunikationswege?.find(kow => kow.kommunikationsWegArt === kowArt.toUpperCase())?.anschluss;
}

function Partnerdaten() {
    const partner = useSelector(selectContentPartner);
    const kommunikationswege = useSelector(selectKommunikationswege);

    if (!partner) {
        return <Fragment />;
    }

    const hauptWohnsitz = getHauptWohnsitz(partner);
    const partnerName = joinNonEmptyParts([
        partner.vorname,
        partner.name
    ]);

    return (
        <Widget title={`Kundenprofil von ${partnerName}`}>
            <Grid container spacing={1}>
                <Grid size={{ xs: 6}}>
                    <strong>{bestimmePartnerTitel(partner)}</strong>
                    <br />
                    <strong>{partnerName}</strong>
                    <br />
                    <>
                        {hauptWohnsitz?.zusatz}
                        <br />
                        {hauptWohnsitz?.strasse} {hauptWohnsitz?.hausnummer}
                        <br />
                        {hauptWohnsitz?.plz} {hauptWohnsitz?.ort}
                    </>
                    <br />
                    <br />
                    <strong>Geb.: </strong> {partner.geburtsDatum}
                </Grid>
                <Grid size={{ xs: 6}}>
                    <>
                        <strong>Tel.:</strong>{' '}
                        {findKOWAnschlussByArt(KowArtEnum.TELEFON, kommunikationswege) ??
                            findKOWAnschlussByArt(KowArtEnum.MOBILFUNK, kommunikationswege)}
                        <br/>
                        <strong>E-Mail:</strong> {findKOWAnschlussByArt(KowArtEnum.EMAIL, kommunikationswege)?.toLocaleLowerCase()}
                    </>
                    <br/>
                    <br/>
                    <strong>Beruf:</strong> {partner.berufBezeichnung}
                    <br/>
                    <strong>Beschäftigungsverhältnis:</strong> {partner.beschaeftigungsverh}
                </Grid>
            </Grid>
        </Widget>
    );
}

export default Partnerdaten;