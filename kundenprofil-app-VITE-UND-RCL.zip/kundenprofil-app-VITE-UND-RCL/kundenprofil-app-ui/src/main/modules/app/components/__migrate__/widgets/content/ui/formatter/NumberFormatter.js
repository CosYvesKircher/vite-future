import {makeStyles} from '@material-ui/core/styles';
import clsx from 'clsx';
import get from 'lodash/get';
import React from 'react';
import PropTypes from 'prop-types';

import {formatCurrency, formatDecimal, formatPercentage} from '../../../../../../../../utils/NumberUtils';

const useStyles = makeStyles((theme) => ({
  root: {
    textAlign: 'right',
    paddingRight: theme.spacing(1)
  },
  quote: {
    paddingRight: theme.spacing(1)
  }
}));

function NumberFormatter({
  row,
  dataField,
  as = 'number' // curreny | quote
}) {
  const classes = useStyles();
  const amount = get(row, dataField);

  let displayValue;
  switch (as) {
  case 'currency':
    displayValue = formatCurrency(amount, true);
    break;


  case 'decimal':
    displayValue = formatDecimal(amount);
    break;

  default:
    displayValue = amount;
  }

  if (displayValue === null || displayValue === undefined) {
    return null;
  }

  return (
    <div className={clsx(classes.root, {[classes.quote]: as === 'quote'})}>
      {displayValue}
    </div>
  );
}

NumberFormatter.propTypes = {
  row: PropTypes.object.isRequired,
  dataField: PropTypes.string.isRequired,
  as: PropTypes.oneOf(['number', 'currency', 'decimal', 'quote'])
};

export default React.memo(NumberFormatter);
