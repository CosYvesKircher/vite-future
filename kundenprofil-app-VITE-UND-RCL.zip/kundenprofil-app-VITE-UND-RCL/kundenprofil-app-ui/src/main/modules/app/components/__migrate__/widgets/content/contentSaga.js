import {ContentActions} from './contentSlice';
import Api from '../../../../../../api/Api';
import {
  call, put, takeEvery
} from 'redux-saga/effects';
import {select} from 'redux-saga-test-plan/matchers';
import {selectPartner, selectDruckwege} from './contentSelectors';

function* workflowLadePartner(action) {
  const parNummer = action.payload;
  console.log('Partnernummer ' + parNummer);

  try {
    const response = yield call(Api.fetchPartnerDaten, parNummer);
    yield put(ContentActions.loadPartnerDatenSuccess(response));
  } catch (e) {
    yield put(ContentActions.loadPartnerDatenError(e));
  }
}

function* workflowLadeDruckwege(action) {
  const parNummer = action.payload;
  console.log('Lade Druckwege fuer Partnernummer ' + parNummer);

  try {
    const response = yield call(Api.fetchDruckwege, parNummer);
    yield put(ContentActions.loadDruckwegeSuccess(response));
  } catch (e) {
    yield put(ContentActions.loadDruckwegeError(e));
  }
}

function* workflowSaveOnlineDruckweg(action) {
  const vsnr = action.payload;
  console.log('Speichere Online Druckweg fuer VSNR ' + vsnr);

  try {
    const response = yield call(Api.fetchSaveOnlineDruckweg, vsnr);
    yield put(ContentActions.loadSaveOnlineDruckwegSuccess(response));

    const partner = yield select(selectPartner);
    yield put(ContentActions.ladeDruckwege(partner.partnerNummer));
  } catch (e) {
    yield put(ContentActions.loadSaveOnlineDruckwegError(e));
  }
}

function* workflowSaveOfflineDruckweg(action) {
  const vsnr = action.payload;
  console.log('Speichere Offline Druckweg fuer VSNR ' + vsnr);

  try {
    const response = yield call(Api.fetchSaveOfflineDruckweg, vsnr);
    yield put(ContentActions.loadSaveOfflineDruckwegSuccess(response));

    const partner = yield select(selectPartner);
    yield put(ContentActions.ladeDruckwege(partner.partnerNummer));
  } catch (e) {
    yield put(ContentActions.loadSaveOfflineDruckwegSuccess(e));
  }
}

function* workflowOnDruckKennzeichenSwitchClicked(action) {
  const druckwege = yield select(selectDruckwege);
  try {
    if(action.payload === 'nein') {
      const response = yield call(Api.fetchSwitchAllDruckwegeToOffline, druckwege);
      yield put(ContentActions.loadSaveOfflineDruckwegSuccess(response));
    }else{
      const response = yield call(Api.fetchSwitchAllDruckwegeToOnline, druckwege);
      yield put(ContentActions.loadSaveOfflineDruckwegSuccess(response));
    }

    const partner = yield select(selectPartner);
    yield put(ContentActions.ladeDruckwege(partner.partnerNummer));
  } catch (e) {
    yield put(ContentActions.loadSaveOfflineDruckwegSuccess(e));
  }
}

function* workflowLadeErweiterterHaushalt(action) {
  try {
    if(action.payload.value === 'erweitert') {
      const response = yield call(Api.fetchLadeErweiterterHaushalt, action.payload.parNummer);
      yield put(ContentActions.ladeErweiterterHaushaltSuccess(response.response.haushaltsPartner));
    }else{
      yield put(ContentActions.ladeErweiterterHaushaltSuccess(null));
    }
  } catch (e) {
    yield put(ContentActions.ladeErweiterterHaushaltError(e));
  }
}

function* workflowSwitch2DokumentView(action) {
  const vsnr = action.payload.vsnr;
  const ladeAktuelleDruckauftraege = action.payload.ladeAktuelleDruckauftraege;
  const ladeHistorischDruckauftraege = action.payload.ladeHistorischDruckauftraege;
  console.log('Lese Druckauftraege VSNR ' + vsnr +
      ' ladeAktuelleDruckauftraege: ' + ladeAktuelleDruckauftraege +
      ' ladeHistorischDruckauftraege: ' + ladeHistorischDruckauftraege);

  try {
    const response = yield call(Api.fetchDruckAuftraege,
        {
          vsnr: vsnr,
          ladeAktuelleDruckauftraege: ladeAktuelleDruckauftraege,
          ladeHistorischDruckauftraege: ladeHistorischDruckauftraege
        },
      );
    yield put(ContentActions.switch2DokumentViewSuccess(response));
  } catch (e) {
    yield put(ContentActions.switch2DokumentViewError(e));
  }
}

function* workflowContent(action) {
  const {payload: formValues} = action;
}

function* contentSaga() {
  yield takeEvery([ContentActions.suche], workflowContent);
  yield takeEvery([ContentActions.ladePartner], workflowLadePartner);
  yield takeEvery([ContentActions.ladeDruckwege], workflowLadeDruckwege);
  yield takeEvery([ContentActions.saveOnlineDruckweg], workflowSaveOnlineDruckweg);
  yield takeEvery([ContentActions.saveOfflineDruckweg], workflowSaveOfflineDruckweg);
  yield takeEvery([ContentActions.switch2DokumentView], workflowSwitch2DokumentView);
  yield takeEvery([ContentActions.onDruckKennzeichenSwitchClicked], workflowOnDruckKennzeichenSwitchClicked);
  yield takeEvery([ContentActions.ladeErweiterterHaushalt], workflowLadeErweiterterHaushalt);
}

export default contentSaga;
