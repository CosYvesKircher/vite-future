import {Grid} from "@mui/material";
import React from "react";
import {useSelector} from "react-redux";
import {selectContentKundenprofil} from "../../../store/content/ContentSelector";
import Typography from "@mui/material/Typography";
import {DataTable} from "@cos/rcl-future/components";

import {VertragsinfoSparteListeEintrag} from "../../../api/interfaces/Partner.interface";
import VertriebswegSparteFormatter from "./formatter/VertriebswegSparteFormatter";
import NumberFormatter from "./formatter/NumberFormatter";

function VersichertesRisikoPanel() {

    const kundenprofil = useSelector(selectContentKundenprofil);

    const columnsRisiko =
        [
            {
                id: 'sparte',
                dataField: 'sparte',
                text: 'Sparte',
                formatter: (row: VertragsinfoSparteListeEintrag) => <VertriebswegSparteFormatter vertriebswegsparteKey={row.sparte ?? ''} />,
                headerStyle: {width: 250}
            },
            {
                id: 'anzahl',
                align: 'center',
                dataField: 'anzahlVertraege',
                text: 'Anzahl',
                headerStyle: {width: 100}
            },
            {
                id: 'jahresnetto',
                align: 'right',
                dataField: 'beitrag',
                text: 'Aktueller Jahres-Nettobeitrag',
                headerStyle: {width: 250},
                formatter: (row: VertragsinfoSparteListeEintrag)=>  <NumberFormatter renderType="currency" value={row.beitrag ?? ''} />
            }
        ];

    const vertragsSparten: VertragsinfoSparteListeEintrag[] = [];
    const fremdvertragsSparten: VertragsinfoSparteListeEintrag[] = [];
    if(kundenprofil?.vertragsinfoSparteListeEintrag){
        kundenprofil?.vertragsinfoSparteListeEintrag.forEach((vertragsSparte) => {
            // TODO: WARUM NICHT GLEICH ALS NUMBER
            if(Number(vertragsSparte.anzahlVertraege) > 0){
                vertragsSparten.push(vertragsSparte);
            } else{
                fremdvertragsSparten.push(vertragsSparte);
            }
        });
    }


    return <>
        <Grid size={{ xs: 12}}>
            <Typography
                color="textPrimary"
                variant="h3"
                // className="headlineTitle"
            >
                Versichertes Risiko
            </Typography>
        </Grid>
        <Grid size={{ xs: 6}} sx={{ p: 2 }}>
            <DataTable
                rows={vertragsSparten}
                columns={columnsRisiko}
                // className={contentClasses.dataTable}
            />
        </Grid>
        <Grid size={{ xs: 6}} sx={{ p: 2 }}>
            <DataTable
                rows={fremdvertragsSparten}
                columns={columnsRisiko}
                // className={contentClasses.dataTable}
            />
        </Grid>
    </>;
}
export default VersichertesRisikoPanel;