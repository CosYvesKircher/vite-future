import {createEnum} from '../../../../utils/enum/enum';

const DruckKennzeichenEnum = createEnum('DruckKennzeichenEnum', {
  JA: {
    value: 'ja',
    label: 'ja'
  },
  NEIN: {
    value: 'nein',
    label: 'nein'
  }
});

export default DruckKennzeichenEnum;
