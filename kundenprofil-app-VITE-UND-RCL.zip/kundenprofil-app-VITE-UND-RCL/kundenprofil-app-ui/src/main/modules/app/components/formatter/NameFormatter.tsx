import { styled } from '@mui/material/styles';
import React from 'react';

type NameFormatterProps = {
    vorname: string;
    name: string;
};

const Root = styled('div')(({ theme }) => ({
    justifyContent: 'center'
}));



const NameFormatter: React.FC<NameFormatterProps> = (props) => {
    return  <Root>{props.vorname + ' ' + props.name}</Root>;
};

export default React.memo(NameFormatter);
