import React from 'react';
import {useDispatch, useSelector} from "react-redux";
import Widget from "../../../../components/Widget";
import {
    selectContentKundenprofil,
} from "../../../../store/content/ContentSelector";

import {
    selectCurrentPage,
    selectDruckwege,
    selectSaveOnlineDruckwegOngoing,
    selectSaveOnlineDruckwegTempVsnr
} from "../../../../store/druckweg/DruckwegSelector";

import LoadingWrapper from "../../../../components/LoadingWrapper";
import {DataTable, DataTablePagination} from "@cos/rcl-future/components";
import {Druckweg} from "../../../../../API-GEN/kundenprofil-app";
import {setCurrentPageAction} from "../../../../store/druckweg/DruckwegStoreTypes";

function createTableColumns() {
    return [
        {
            id: 'vsnr',
            dataField: 'vsnr',
            text: 'VSNR',
            width: 55
        },
        {
            id: 'sparte',
            dataField: 'sparte',
            text: 'Sparte'
        },
        {
            id: 'druckweg',
            dataField: 'druckweg',
            text: 'Druckweg',
            formatter: (row:any) => {
                if (row.druckweg === 'N') {
                    return 'Postversand';
                } else if (row.druckweg === 'J') {
                    return 'mCD-Versand';
                }


                return row.druckweg;
            },
            width: 120,
            headerStyle: {width: '120px'}
        },
        {
            id: 'menu',
            headerStyle: {width: '100px'},
            text: '',
            //formatter: <DruckwegeMenuFormatter/>
        }
    ];
}

function evaluateDruckwegeArray(druckwege:Druckweg[], pagesAmount: number, page:number, currentSliceEnd: number, currentSliceStart: number, pagemaxPerItem: number) {
    if (druckwege) {
        if (pagesAmount && (page === pagesAmount - 1)) {
            currentSliceEnd = druckwege.length;
        } else {
            currentSliceEnd = currentSliceStart + pagemaxPerItem;
        }

        return druckwege.slice(currentSliceStart, currentSliceEnd);
    }
    return [];
}

function calcPages(itemsPerPage: number, arrLength: number) {
    if (itemsPerPage !== undefined && arrLength !== undefined) {
        return Math.ceil(arrLength / itemsPerPage) || 1;
    }
    return undefined;
}

function DruckwegWidget() {
    const kundenprofil = useSelector(selectContentKundenprofil);
    const saveOnlineDruckwegTempVsnr = useSelector(selectSaveOnlineDruckwegTempVsnr);
    const saveOnlineDruckwegOngoing = useSelector(selectSaveOnlineDruckwegOngoing);
    const druckwege = useSelector(selectDruckwege);
    const page = useSelector(selectCurrentPage);

    const dispatch = useDispatch();

    let druckwegColumns = createTableColumns();

    const pagemaxPerItem = 5;
    const pagesAmount = calcPages(pagemaxPerItem, druckwege?.length);
    const currentSliceStart = page * pagemaxPerItem;
    let currentSliceEnd = 0;

    let druckwegSubArray:Druckweg[] = evaluateDruckwegeArray(druckwege, pagesAmount, page, currentSliceEnd, currentSliceStart, pagemaxPerItem);

    const title = "Vertriebsweg Erstvertrag";
    const toolbarRenderer = () => {
        return (
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'end', width: '100%'}}>
                <Text value={'Dokumente zum Vertrag Online erhalten'} style={{paddingLeft: 8, paddingRight: 12}}/>

                {saveOnlineDruckwegOngoing &&
                    <div style={{paddingRight: '28px', paddingLeft: '28px'}}>
                        <LoadingWrapper size={22} />
                    </div>
                }
            </div>
        );
    };

    const handleChangePage = (event, newPage) => {
        console.log('handleChange');

        dispatch(setCurrentPageAction(newPage));
    };

    const handleChangeRowsPerPage = event => {
        console.log('HandleChangeRowsPerPage');
    };

    return (
        <Widget title="Druckweg" toolbarRenderer={toolbarRenderer}>
            <DataTable
                rows={druckwegSubArray}
                columns={druckwegColumns}
                data-testid={'druckweg-table'}
            />

            <DataTablePagination
                component="div"
                style={{display: 'flex', justifyContent: 'flex-end'}}
                count={druckwege && druckwege.length}
                colSpan={druckwegColumns.length}
                rowsPerPage={5}
                page={page}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeRowsPerPage}>
            </DataTablePagination>
        </Widget>
    );
}

export default DruckwegWidget;