import React from 'react';

import {useSelector} from 'react-redux';
import {selectContentSpartenMappings} from "../../../../store/content/ContentSelector";
import {SpartenMapping} from "../../../../api/interfaces/Partner.interface";

type VertriebswegSparteFormatterProps = {
    vertriebswegsparteKey: string;
};

const VertriebswegSparteFormatter: React.FC<VertriebswegSparteFormatterProps> = ({
                                                                                     vertriebswegsparteKey
                                                         }) => {
    const spartenMappings = useSelector(selectContentSpartenMappings) as SpartenMapping[];
    const mappingFound = spartenMappings.find(mapping => mapping.key === vertriebswegsparteKey);
    const spartenText = mappingFound ? mappingFound.value : vertriebswegsparteKey;


    // TODO WARUM ???
    // if(isEmpty(spartenText)){
    //     spartenText = 'Tagesgeld';
    // }

    return (
        <>
            {spartenText}
        </>
    );
}

export default VertriebswegSparteFormatter;