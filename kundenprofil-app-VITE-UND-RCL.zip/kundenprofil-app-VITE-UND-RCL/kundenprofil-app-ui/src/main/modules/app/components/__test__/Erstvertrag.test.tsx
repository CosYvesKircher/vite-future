import React from 'react';
import Erstvertrag from '../Erstvertrag';
import {describe, expect, it} from 'vitest';
import {ContentStateType} from "../../../../store/content/ContentStoreTypes";
import {RemoteLoadingState} from "../../../../utils/rest/RemoteStateUtils";
import {render, screen} from '../../../../../test-utils';


describe('Erstvertrag', () => {
    it('zeigt den Titel und Kunde seit an', () => {
        const contentOverrides : ContentStateType = {
            remote: {
                loadingState: RemoteLoadingState.loaded,
                remoteError: null
            },
            kundenprofil: {
                vertriebsweg: {
                    vertriebswegName: 'Vertriebsweg Test',
                    vertriebswegDatum: '2022-01-01',
                    vertriebswegSparte: 'FR',
                    verNummer: 123,
                    vertriebswegNummer: "123"
                },
                vertragsinfoListeEintrag: [{}],
                kundeSeit: '2020-01-01',
            },
            spartenMappings: [
                {
                    "key": "FR",
                    "value": "Fremdversicherung"
                },
                {
                    "key": "H",
                    "value": "Haftpflicht Cosmos"
                },
                {
                    "key": "HR",
                    "value": "Hausratversicherung"
                },
                {
                    "key": "A",
                    "value": "Kraftfahrt Cosmos"
                },
                {
                    "key": "ZK",
                    "value": "Krankenzusatzversicherung"
                },
                {
                    "key": "L",
                    "value": "Lebensversicherung"
                },
                {
                    "key": "RV",
                    "value": "Reiseversicherung"
                },
                {
                    "key": "SV",
                    "value": "Sonstige Vermögensschäden"
                },
                {
                    "key": "U",
                    "value": "Unfall"
                },
                {
                    "key": "W",
                    "value": "Wohngebäudeversicherung"
                },
                {
                    "key": "ZT",
                    "value": "Zusatztarife für künstliche Deckungen (spartenübergreifend)"
                }
            ]
        };

        render(<Erstvertrag />, {
            preloadedState: {
                ...{content: contentOverrides}
            }
        });

        expect(screen.getByText('Vertriebsweg Erstvertrag')).toBeInTheDocument();
        expect(screen.getByText(/Kunde seit:/)).toBeInTheDocument();
        expect(screen.getByText('2020-01-01')).toBeInTheDocument();
        expect(screen.getByText('Vertriebsweg Test')).toBeInTheDocument();
        expect(screen.getByText('2022-01-01')).toBeInTheDocument();
        expect(screen.getByText('Fremdversicherung')).toBeInTheDocument(); // oder, falls Mapping aktiv: expect(screen.getByText('...')).toBeInTheDocument();

    });
});
