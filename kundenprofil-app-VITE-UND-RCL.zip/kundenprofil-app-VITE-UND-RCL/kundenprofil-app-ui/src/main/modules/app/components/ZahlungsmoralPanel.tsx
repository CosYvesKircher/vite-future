import {Box, Grid, styled} from "@mui/material";
import React, {Fragment} from "react";
import {useSelector} from "react-redux";
import {selectContentKundenprofil} from "../../../store/content/ContentSelector";
import Typography from "@mui/material/Typography";
import {DataTable} from "@cos/rcl-future/components";
import NumberFormatter from "../../../components/formatters/NumberFormatter";
import {formatCurrency} from "../../../utils/NumberUtils";
import {VertragsinfoSparteListeEintrag} from "../../../api/interfaces/Partner.interface";
import parseDatumUhrzeit from "../../../utils/DatumUhrzeitUtils";
import {Kundenprofil} from "../../../../API-GEN/kundenprofil-app";
import {Colors} from "@cos/rcl-future/theme";


// function createScoringLabel(kundenprofil, contentClasses) {
//     if (kundenprofil?.zahlungsinfo?.scoringWert === 'Grün'){
//         return (
//             <label className={contentClasses.scoringgruen}>
//                 Scoring
//             </label>
//         );
//     }else if(kundenprofil?.zahlungsinfo?.scoringWert === 'Rot'){
//         return (
//             <label className={contentClasses.scoringrot}>
//                 Scoring
//             </label>
//         );
//     }else if(kundenprofil?.zahlungsinfo?.scoringWert === 'Orange'){
//         return (
//             <label className={contentClasses.scoringorange}>
//                 Scoring
//             </label>
//         );
//     }
//
//     return (
//         <Typography color={'initial'} display={'block'}>
//             <label className={contentClasses.zahlungsmorallabel}>
//                 Scoring
//             </label>
//         </Typography>
//     );
// }


function ermittleClassForMahnverfahrenLabel(kundenprofil: Kundenprofil) {
    const anzahlMahnverfahrenOffen = kundenprofil?.zahlungsinfo?.anzahlMahnverfahrenOffen;
    if (Number(anzahlMahnverfahrenOffen) > 0) {
        return 'rot headline';
    }
    return 'gruen headline';
}
function ermittleClassForScoringLabel(kundenprofil: Kundenprofil) {
    const scoringWert = kundenprofil?.zahlungsinfo?.scoringWert;
    if (scoringWert === 'Grün') {
        return 'gruen headline';
    } else if (scoringWert === 'Rot') {
        return 'rot headline';
    } else if (scoringWert === 'Orange') {
        return 'orange headline';
    }
    return 'headline';
}

function ermittleClassesForSaldoHeadline(kundenprofil: Kundenprofil) {
    // TODO Pruefen of fachlich korrekt, warum nciht gleich number?
    let saldo = kundenprofil?.zahlungsinfo?.aktuellerKundensaldo;
    if (Number(saldo) < 0) {
        return 'rot headline';
    } else {
        return 'gruen headline';
    }
}

const ZahlungsmoralPanelGrid = styled(Grid)(({ theme }) => ({
    paddingBottom: theme.spacing(2),
    ".text": {
        paddingLeft: theme.spacing(0.5),
    },
    ".headline": {
        backgroundColor: Colors.COSMOS_BLAU_HELLER_5,
        padding: theme.spacing(1),
        fontWeight: '600'
    },
    ".rot": {
        color: theme.palette.error.main
    },
    ".gruen": {
        color: theme.palette.success.main
    },
    '.orange': {
        color: Colors.COSMOS_ORANGE
    }
}));

function ZahlungsmoralPanel() {

    const kundenprofil = useSelector(selectContentKundenprofil);

    return <Grid size={{ xs: 12}}>
        <ZahlungsmoralPanelGrid container spacing={2}>
            <Grid size={{ xs: 12}}>
                <Typography
                    color="textPrimary"
                    variant="h3"
                    // className="headlineTitle"
                >
                    Zahlungsmoral
                </Typography>
            </Grid>
            <Grid size={{ xs: 6}}>
                <Box display="flex" alignItems="center" gap={2}>
                    <Box className={ermittleClassesForSaldoHeadline(kundenprofil)}>
                        Aktueller Kundensaldo
                    </Box>
                    <Box className="text">
                        {formatCurrency(kundenprofil?.zahlungsinfo?.aktuellerKundensaldo)}
                    </Box>
                </Box>
            </Grid>
            <Grid size={{ xs: 3}}>
                <Box display="flex" alignItems="center" gap={2}>
                    <Box className={ermittleClassForScoringLabel(kundenprofil)}>
                        Socring
                    </Box>
                    <Box className="text">
                        {parseDatumUhrzeit(kundenprofil?.zahlungsinfo?.scoringDatum)}
                    </Box>
                </Box>
            </Grid>
            <Grid size={{ xs: 3}}>
                <Box display="flex" alignItems="center" gap={2}>
                    <Box className={ermittleClassForMahnverfahrenLabel(kundenprofil)}>
                        Mahnverfahren
                    </Box>
                    <Box className="text">
                        {kundenprofil?.zahlungsinfo?.anzahlMahnverfahrenOffen}
                    </Box>
                </Box>
            </Grid>
        </ZahlungsmoralPanelGrid>
    </Grid>

}
export default ZahlungsmoralPanel;