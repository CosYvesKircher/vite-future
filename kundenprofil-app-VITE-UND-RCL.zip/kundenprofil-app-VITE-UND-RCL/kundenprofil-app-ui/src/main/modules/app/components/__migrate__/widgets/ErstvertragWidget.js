import React, {Fragment} from 'react';
import {useSelector} from 'react-redux';

import Widget from '../../../../components/Widget';
import ContentSelectors from '../../contentSelectors';
import {REMOTE_STATE} from '../../../../utils/rest/restUtils';
import {makeStyles} from '@material-ui/core/styles';
import {Box, Grid, Typography} from '@material-ui/core';
import LoadingProgress from '@cos/react-component-library/components/spinner/LoadingProgress';
import Text from '@cos/react-component-library/components/text/Text';
import {isEmpty} from '@cos/react-component-library/utils/emptyUtils';
import VertriebswegSparteFormatter from '../formatter/VertriebswegSparteFormatter';
import DataTable from '@cos/react-component-library/components/datatable/DataTable';

const useWidgetStyles = makeStyles(() => ({
  root: {
    minHeight: '2rem',
    height: '100%',
    width: '100%'
  },
  contentWrapper: {
    padding: 0,
    margin: 0,
    height: '100%'
  },
  content: {
    padding: 0,
    margin: 0
  }
}));

const useContentStyles = makeStyles(() => ({
  contentArea: {
    padding: 0,
    margin: 0
  },
  area: {
    paddingTop: 16,
    paddingLeft: 10
  },
  label: {
    paddingTop: 0,
    fontWeight: '600'
  },
  gridItem: {
    padding: '0.5rem 1rem'
  },
  center: {
    textAlign: 'center'
  },
  dataTable: {
    width: '100%'
  },
  box: {
    width: '100%',
    paddingTop: 20
  }
}));

function createDatatable(kundenprofil, rows, columns, contentClasses) {
  if(!isEmpty(rows)){
    return (
      <DataTable
        rows={rows}
        columns={columns}
        className={contentClasses.dataTable}
      />
    );
  }else{
    const emptyRow = [
      {
        'verNummer': 0,
        'vertriebswegNummer': 'Keine Daten vorhanden',
        'vertriebswegName': '',
        'vertriebswegDatum': '',
        'vertriebswegSparte': ''
      }
    ]
    return (
        <DataTable
            rows={emptyRow}
            columns={columns}
            className={contentClasses.dataTable}
        />
    );
  }
}

function createErstvertragPanel(contentClasses, partner, kundenprofil){
  const columns =
      [
        {
          id: 'vertriebsweg',
          dataField: 'vertriebswegNummer',
          text: 'VW',
          headerStyle: {width: 50}
        },
        {
          id: 'vertriebswegName',
          dataField: 'vertriebswegName',
          text: 'Name Vertriebsweg',
          headerStyle: {width: 2}
        },
        {
          id: 'Datum',
          dataField: 'vertriebswegDatum',
          text: 'Datum',
          headerStyle: {width: 50}
        },
        {
          id: 'Sparte',
          dataField: 'vertriebswegSparte',
          text: 'Sparte',
          headerStyle: {width: 150},
          formatter: <VertriebswegSparteFormatter/>
        }
      ];

  const rows = [];
  if(kundenprofil.vertriebsweg && !isEmpty(kundenprofil?.vertriebsweg.verNummer)){
    rows.push(kundenprofil.vertriebsweg)
  }

  return (
    <Grid className={contentClasses.contentArea}>
      <Grid className={contentClasses.area} container item xs={12}>
        <Typography component="div">
          <Fragment>
            <strong>Kunde seit: </strong>
            {!isEmpty(kundenprofil?.vertragsinfoListeEintrag) ? kundenprofil?.kundeSeit : ''}
          </Fragment>
        </Typography>
        <Box className={contentClasses.box}>
          {createDatatable(kundenprofil, rows, columns, contentClasses)}
        </Box>
      </Grid>

      <Grid container item xs={6}>
        <Typography component="div">
          <Fragment>
          </Fragment>
        </Typography>
      </Grid>
    </Grid>
  );
}

function ErstvertragWidget() {
  const widgetClasses = useWidgetStyles();
  const contentClasses = useContentStyles();
  const {remoteState} = useSelector(ContentSelectors.selectRemoteState);
  const partner = useSelector(ContentSelectors.selectPartner);
  const kundenprofil = useSelector(ContentSelectors.selectKundenprofil);

  if (remoteState === REMOTE_STATE.LOADED && kundenprofil) {
    return (
      <Widget classes={widgetClasses} title="Vertriebsweg Erstvertrag">
        {createErstvertragPanel(contentClasses, partner, kundenprofil)}
      </Widget>
    );
  }
  if (remoteState === REMOTE_STATE.LOADED && !kundenprofil) {
    return (
        <Widget classes={widgetClasses} title="Vertriebsweg Erstvertrag">
          Vertriebsweg konnte nicht gefunden werden!
        </Widget>
    );
  } else if (remoteState === REMOTE_STATE.ERROR) {
    return (
        <Widget classes={widgetClasses} title="Vertriebsweg Erstvertrag">
          Fehler beim Laden der Vertriebswege!
        </Widget>
    );
  } else {
    return (
      <Widget classes={widgetClasses}>
        <div>
          <LoadingProgress/>
          <Text className={contentClasses.center} value={'wird geladen...'}/>
        </div>
      </Widget>
    );
  }
}

export default ErstvertragWidget;
