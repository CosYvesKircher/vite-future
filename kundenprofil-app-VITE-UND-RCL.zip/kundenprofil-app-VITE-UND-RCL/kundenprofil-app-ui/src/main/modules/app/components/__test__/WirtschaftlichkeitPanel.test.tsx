import React from 'react';
import {describe, expect, it} from 'vitest';
import {render, screen} from '../../../../../test-utils';
import WirtschaftlichkeitPanel from "../WirtschaftlichkeitPanel";

describe('Wirtschaftlichkeit Panel', () => {
    it('zeigt die gemappten Sparten-Namen an', () => {
        const contentOverrides = {
            kundenprofil: {
                kundenprofilRentabilitaetGesamt: {
                    anzahlLeistung: "10",
                    summeLeistung: "1000",
                    anzahlSchaden: "5",
                    summeSchaden: "500",
                    gesamtJahresBeitrag: "1500",
                    kompositSchadenquote: "33%"
                }
            }
        };

        render(<WirtschaftlichkeitPanel />, {
            preloadedState: {
                content: contentOverrides
            }
        });

        expect(screen.getByText('Leistung Leben')).toBeInTheDocument();
        expect(screen.getByText('Schaden Komposit')).toBeInTheDocument();
        expect(screen.getByText('Gesamtbetrag:')).toBeInTheDocument();
        expect(screen.getByText('1.500,00 €')).toBeInTheDocument();
        expect(screen.getByText('Komposit-Schadenquote:')).toBeInTheDocument();
        expect(screen.getByText('33%')).toBeInTheDocument();
    });
});
