import React from 'react';

import {mockStore, render, screen} from '../../../../../../test-utils';
//import {REMOTE_STATE} from '../utils/rest/restUtils';
import AppUI from '../../../AppUI';
import {Provider} from "react-redux";

describe('<AppUI>', () => {
  /*
  it('zeigt keine Ausgabe wenn noch keine Daten geladen wurden', () => {
    const {container} = render(
      <AppUI remoteState={REMOTE_STATE.NOT_LOADED} />,
    );
    expect(container.firstChild).toBeNull();
  });

  it('zeigt Lade-Hinweis wenn gerade Daten geladen werden', () => {
    render(<AppUI remoteState={REMOTE_STATE.LOADING} />);
    expect(screen.queryByText(/Laden/i)).not.toBeNull();
  });

  it('zeigt Fehler-Dialog wenn keine Daten geladen werden konnten', () => {
    render(
      <AppUI
        remoteState={REMOTE_STATE.ERROR}
        remoteError="Nur ein Unit-Test"
      />,
    );
    expect(screen.getByRole('dialog')).toHaveTextContent(
      /Es ist ein Fehler aufgetreten/i,
    );
  });

  it('zeigt ein Grid mit Modulen wenn Daten erfolgreich geladen wurden', () => {
    render(<AppUI remoteState={REMOTE_STATE.LOADED} />);
    expect(screen.queryByTestId('app-grid-partnerdaten')).not.toBeNull();
  });

  it('zeigt ein Grid mit Modulen wenn Daten erfolgreich geladen wurden -> mit State', () => {
    const newstore = mockStore({
      common: {},
      user: {
        remote: {
          remoteState: 'LOADED',
          remoteError: null
        },
        environment: {
          authenticatedUsername: 'i05alfb',
          db: 'Q60APP',
          restTimeout: 40000,
          tester: false
        }
      },
      content: {
        view: {
          availableTabs: [],
          currentTab: null
        },
        form: {
          maKuerzel: ''
        },
        remote: {
          remoteState: 'LOADED',
          remoteError: null
        },
        suchergebnisse: [],
        parNummer: '91563184',
        partner: {
          validator: null,
          partnerNummer: 91563184,
          anrede: 'HERR',
          anredeCode: 1,
          name: 'MAIER',
          vorname: 'BERNHARD',
          geburtsDatum: '25.02.1970',
          geburtsJahr: null,
          adressen: [
            {
              validator: null,
              adressId: '0',
              laufendeNummer: '1',
              strasse: 'MAINZER STR.',
              zusatz: null,
              hausnummer: '125',
              plz: '66121',
              ort: 'SAARBRÜCKEN',
              land: 'D',
              adressTyp: 'HAUPTWOHNSITZ',
              adresstypCode: null,
              gueltigAb: '16.03.2010',
              gueltigBis: '31.12.2999',
              inaktivAb: null,
              updateZahl: 1629126
            }
          ],
          sterbedatum: null,
          status: 'UNBEKANNT',
          titel: 'KEIN_TITEL',
          berufBezeichnung: 'POLIZIST',
          berufCode: '801470',
          letzteAenderung: '16.09.2025',
          scoring: 'GRAY',
          beschaeftigungsverh: 'Angestellter',
          beschaeftigungCode: 'ANG',
          familienStand: 'UNVERHEIRATET_SINGLE',
          familienStandCode: 'U',
          anzahlKinder: null,
          geburtslandCode: 'D',
          geburtsOrt: 'SAARBRÜCKEN',
          staatsangehoerigkeitCode: 'D',
          haushaltsRolle: 'CHEF',
          updateZahl: 10814888
        },
        kundenprofil: {
          parNummer: 91563184,
          korrelationsid: null,
          vertriebsweg: {
            verNummer: null,
            vertriebswegNummer: null,
            vertriebswegName: null,
            vertriebswegDatum: null,
            vertriebswegSparte: null
          },
          kundeSeit: '01.10.2007',
          zahlungsinfo: {
            validator: null,
            aktuellerKundensaldo: '-4556.69',
            scoringWert: 'Grün',
            scoringDatum: '2025-05-07T00:00',
            anzahlMahnverfahrenOffen: '0',
            anzahlMahnverfahrenHistorie: '0',
            infoText: null
          },
          kundenprofilRentabilitaetGesamt: {
            validator: null,
            gesamtJahresBeitrag: '124959.5',
            kompositSchadenquote: '0',
            anzahlLeistung: '0',
            summeLeistung: '0',
            anzahlSchaden: '0',
            summeSchaden: '0'
          },
          kundenprofilRentabilitaet: [
            {
              validator: null,
              jahr: '2020',
              beitraege: '780.8',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              validator: null,
              jahr: '2021',
              beitraege: '782.63',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              validator: null,
              jahr: '2022',
              beitraege: '783.64',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              validator: null,
              jahr: '2023',
              beitraege: '735.86',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              validator: null,
              jahr: '2024',
              beitraege: '741.68',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              validator: null,
              jahr: '2025',
              beitraege: '820.43',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            }
          ],
          beschwerdeListeEintrag: null,
          mahnvertragsDaten: [
            {
              validator: null,
              vertrag: '200072673',
              saldo: '0',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '200074578',
              saldo: '0',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '200075652',
              saldo: '0',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '200083153',
              saldo: '0',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '300003829',
              saldo: '0',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '500117651',
              saldo: '-24.28',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '500117652',
              saldo: '-34.58',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '920088283',
              saldo: '0',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '920088368',
              saldo: '-623.56',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '920088370',
              saldo: '-613.18',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '920114276',
              saldo: '0',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            },
            {
              validator: null,
              vertrag: '920344815',
              saldo: '-3261.09',
              mahnverfahren: 'N',
              unbezahltSeit: null,
              mahnzweig: null,
              grund: null
            }
          ],
          rentaLeistungListe: null,
          vertragsinfoSparteListeEintrag: [
            {
              validator: null,
              sparte: 'A',
              anzahlVertraege: '5',
              beitrag: '2789.88',
              versicherungssumme: '0'
            },
            {
              validator: null,
              sparte: 'H',
              anzahlVertraege: '2',
              beitrag: '49.46',
              versicherungssumme: '0'
            },
            {
              validator: null,
              sparte: 'KP',
              anzahlVertraege: '0',
              beitrag: '0',
              versicherungssumme: '0'
            },
            {
              validator: null,
              sparte: 'L',
              anzahlVertraege: '3',
              beitrag: '122120.16',
              versicherungssumme: '50259.46'
            }
          ],
          vertragsinfoListeEintrag: [
            {
              validator: null,
              vertag: '200072673',
              beitrag: '0',
              tarif: 'Risikoversicherung CR.64 (CR.64)',
              sparte: 'L',
              versicherungssumme: '50000',
              vertragsbeginn: '2010-04-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: null
            },
            {
              validator: null,
              vertag: '200074578',
              beitrag: '20000',
              tarif: 'Aufgeschobene Rentenvers. | Flexibles Vorsorgekonto geg. EB 08.2010 (RFVE-60)',
              sparte: 'L',
              versicherungssumme: '105.67',
              vertragsbeginn: '2007-10-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '200075652',
              beitrag: '2120.16',
              tarif: 'Aufgeschobene Rentenversicherung | Flexibler Vorsorgeplan 08.2010 (RFV-60)',
              sparte: 'L',
              versicherungssumme: '153.79',
              vertragsbeginn: '2009-01-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '200083153',
              beitrag: '100000',
              tarif: 'Fondsgebundene Rentenversicherung | FlexVoKonto Invest 09.2011 (FFVE-60)',
              sparte: 'L',
              versicherungssumme: null,
              vertragsbeginn: '2012-04-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '300003829',
              beitrag: null,
              tarif: 'KP',
              sparte: 'KP',
              versicherungssumme: null,
              vertragsbeginn: '2011-11-18T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: null
            },
            {
              validator: null,
              vertag: '500117651',
              beitrag: '20.4',
              tarif: 'H',
              sparte: 'H',
              versicherungssumme: null,
              vertragsbeginn: '2025-06-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '500117652',
              beitrag: '29.06',
              tarif: 'H',
              sparte: 'H',
              versicherungssumme: null,
              vertragsbeginn: '2025-05-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '920088283',
              beitrag: '1491.66',
              tarif: 'A',
              sparte: 'A',
              versicherungssumme: null,
              vertragsbeginn: '2010-03-22T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '920088368',
              beitrag: '261.99',
              tarif: 'A',
              sparte: 'A',
              versicherungssumme: null,
              vertragsbeginn: '2010-04-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '920088370',
              beitrag: '257.64',
              tarif: 'A',
              sparte: 'A',
              versicherungssumme: null,
              vertragsbeginn: '2010-04-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '920114276',
              beitrag: '498.85',
              tarif: 'A',
              sparte: 'A',
              versicherungssumme: null,
              vertragsbeginn: '2015-09-14T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            },
            {
              validator: null,
              vertag: '920344815',
              beitrag: '279.74',
              tarif: 'A',
              sparte: 'A',
              versicherungssumme: null,
              vertragsbeginn: '2016-01-01T00:00',
              systemKnz: 'ICIS',
              anzahlVertraege: '1'
            }
          ],
          kundenRentaSparteListes: [
            {
              sparte: 'A',
              jahr: '2020',
              beitraege: '780.8',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              sparte: 'A',
              jahr: '2021',
              beitraege: '782.63',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              sparte: 'A',
              jahr: '2022',
              beitraege: '783.64',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              sparte: 'A',
              jahr: '2023',
              beitraege: '735.86',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              sparte: 'A',
              jahr: '2024',
              beitraege: '741.68',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              sparte: 'A',
              jahr: '2025',
              beitraege: '770.97',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            },
            {
              sparte: 'H',
              jahr: '2025',
              beitraege: '49.46',
              anzahlSchaden: null,
              schadenaufwand: null,
              quote: null
            }
          ],
          rentaSchadenListes: null,
          besondereRollen: null,
          mahnhistorie: null,
          uniwagnis: null,
          uniwagnisSparte: null
        },
        druckwege: [
          {
            vsnr: 300003829,
            sparte: 'Tagesgeld Plus',
            druckweg: 'N'
          },
          {
            vsnr: 920088370,
            sparte: 'Autoversicherung',
            druckweg: 'N'
          },
          {
            vsnr: 500117651,
            sparte: 'Privat-Haftpflichtversicherung',
            druckweg: 'N'
          },
          {
            vsnr: 920088283,
            sparte: 'Autoversicherung',
            druckweg: 'N'
          },
          {
            vsnr: 920344815,
            sparte: 'Autoversicherung',
            druckweg: 'J'
          },
          {
            vsnr: 200072673,
            sparte: 'Risiko-Lebensversicherung',
            druckweg: 'N'
          },
          {
            vsnr: 920088368,
            sparte: 'Autoversicherung',
            druckweg: 'N'
          },
          {
            vsnr: 200075652,
            sparte: 'Flexibler VorsorgePlan',
            druckweg: 'N'
          },
          {
            vsnr: 200083153,
            sparte: 'Flexibles VorsorgeKonto Invest',
            druckweg: 'J'
          },
          {
            vsnr: 920114276,
            sparte: 'Autoversicherung',
            druckweg: 'N'
          },
          {
            vsnr: 500117652,
            sparte: 'Privat-Haftpflichtversicherung',
            druckweg: 'N'
          },
          {
            vsnr: 200074578,
            sparte: 'Flexibles VorsorgeKonto',
            druckweg: 'N'
          }
        ],
        ladeDruckwege: false,
        editVsnr: null,
        spartenMappings: [
          {
            key: 'FR',
            value: 'Fremdversicherung'
          },
          {
            key: 'H',
            value: 'Haftpflicht Cosmos'
          },
          {
            key: 'HR',
            value: 'Hausratversicherung'
          },
          {
            key: 'A',
            value: 'Kraftfahrt Cosmos'
          },
          {
            key: 'ZK',
            value: 'Krankenzusatzversicherung'
          },
          {
            key: 'L',
            value: 'Lebensversicherung'
          },
          {
            key: 'HL',
            value: 'Linke Haftpflichtversicherung'
          },
          {
            key: 'RV',
            value: 'Reiseversicherung'
          },
          {
            key: 'SV',
            value: 'Sonstige Vermögensschäden'
          },
          {
            key: 'LI',
            value: 'Testprodukt Andreas Linke'
          },
          {
            key: 'U',
            value: 'Unfall'
          },
          {
            key: 'W',
            value: 'Wohngebäudeversicherung'
          },
          {
            key: 'ZT',
            value: 'Zusatztarife für künstliche Deckungen (spartenübergreifend)'
          }
        ],
        haushaltspartner: [
          {
            validator: null,
            partnerNummer: 93261618,
            anrede: 'HERR',
            anredeCode: 1,
            name: 'MEIER2',
            vorname: 'BERNI',
            geburtsDatum: null,
            geburtsJahr: '9999',
            adressen: [
              {
                validator: null,
                adressId: '0',
                laufendeNummer: '1',
                strasse: 'HALBERGSTR.',
                zusatz: null,
                hausnummer: '1',
                plz: '66121',
                ort: 'SAARBRÜCKEN',
                land: 'D',
                adressTyp: 'HAUPTWOHNSITZ',
                adresstypCode: null,
                gueltigAb: '27.10.2025',
                gueltigBis: '31.12.2999',
                inaktivAb: null,
                updateZahl: 10820067
              }
            ],
            sterbedatum: null,
            status: 'UNBEKANNT',
            titel: 'KEIN_TITEL',
            berufBezeichnung: 'UNBEKANNT',
            berufCode: '000009',
            letzteAenderung: '27.10.2025',
            scoring: 'GRAY',
            beschaeftigungsverh: null,
            beschaeftigungCode: null,
            familienStand: 'UNBEKANNT',
            familienStandCode: null,
            anzahlKinder: null,
            geburtslandCode: null,
            geburtsOrt: null,
            staatsangehoerigkeitCode: 'D',
            haushaltsRolle: 'MITGLIED',
            updateZahl: 10820066
          },
          {
            validator: null,
            partnerNummer: 93261599,
            anrede: 'FRAU',
            anredeCode: 2,
            name: 'MEIER',
            vorname: 'BERNHARDINA',
            geburtsDatum: '01.01.1970',
            geburtsJahr: null,
            adressen: [
              {
                validator: null,
                adressId: '0',
                laufendeNummer: '1',
                strasse: 'MAINZER STR.',
                zusatz: null,
                hausnummer: '125',
                plz: '66121',
                ort: 'SAARBRÜCKEN',
                land: 'D',
                adressTyp: 'HAUPTWOHNSITZ',
                adresstypCode: null,
                gueltigAb: '27.10.2025',
                gueltigBis: '31.12.2999',
                inaktivAb: null,
                updateZahl: 10820099
              }
            ],
            sterbedatum: null,
            status: 'UNBEKANNT',
            titel: 'KEIN_TITEL',
            berufBezeichnung: 'UNBEKANNT',
            berufCode: '000009',
            letzteAenderung: '27.10.2025',
            scoring: 'GRAY',
            beschaeftigungsverh: null,
            beschaeftigungCode: null,
            familienStand: 'UNBEKANNT',
            familienStandCode: null,
            anzahlKinder: null,
            geburtslandCode: null,
            geburtsOrt: null,
            staatsangehoerigkeitCode: 'D',
            haushaltsRolle: 'MITGLIED',
            updateZahl: 10820098
          },
          {
            validator: null,
            partnerNummer: 93261622,
            anrede: 'HERR',
            anredeCode: 1,
            name: 'MÜLLER',
            vorname: 'MAX',
            geburtsDatum: '01.01.1980',
            geburtsJahr: null,
            adressen: [
              {
                validator: null,
                adressId: '0',
                laufendeNummer: '1',
                strasse: 'MAINZER STR.',
                zusatz: null,
                hausnummer: '125',
                plz: '66121',
                ort: 'SAARBRÜCKEN',
                land: 'D',
                adressTyp: 'HAUPTWOHNSITZ',
                adresstypCode: null,
                gueltigAb: '27.10.2025',
                gueltigBis: '31.12.2999',
                inaktivAb: null,
                updateZahl: 10820071
              }
            ],
            sterbedatum: null,
            status: 'UNBEKANNT',
            titel: 'KEIN_TITEL',
            berufBezeichnung: 'UNBEKANNT',
            berufCode: '000009',
            letzteAenderung: '27.10.2025',
            scoring: 'GRAY',
            beschaeftigungsverh: null,
            beschaeftigungCode: null,
            familienStand: 'UNBEKANNT',
            familienStandCode: null,
            anzahlKinder: null,
            geburtslandCode: null,
            geburtsOrt: null,
            staatsangehoerigkeitCode: 'D',
            haushaltsRolle: 'MITGLIED',
            updateZahl: 10820070
          }
        ],
        showDokumentView: false,
        loadingDokumentView: false,
        dokumentViewVsnr: null,
        saveOnlineDruckwegOngoing: false,
        saveOnlineDruckwegTempVsnr: null,
        saveOfflineDruckwegOngoing: false,
        onDruckKennzeichenSwitchValue: 'nein',
        currentPage: 0
      }
    });

    //todo
   /!* const {getByText, getByTestId} = render(
        <Provider store={newstore}>
          <AppUI remoteState={REMOTE_STATE.LOADED}  />
        </Provider>
    );
    expect(screen.queryByTestId('app-grid-partnerdaten')).not.toBeNull();
    expect(screen.queryByTestId('app-grid-druckweg')).not.toBeNull();
    expect(screen.queryByTestId('app-grid-kundenprofil')).not.toBeNull();
    expect(screen.queryByTestId('druckweg-table')).not.toBeNull();*!/
  });*/
});
