import {createSlice} from '@reduxjs/toolkit';

import {
  initRemote, markRemoteError, markRemoteLoaded, markRemoteLoading
} from '../../utils/rest/restUtils';

const EMPTY_STRING = '';
const EMPTY_ARRAY = [];

export const initialSucheState = {
  view: {
    availableTabs: EMPTY_ARRAY,
    currentTab: null
  },
  form: {
    maKuerzel: EMPTY_STRING
  },
  remote: initRemote(),
  suchergebnisse: EMPTY_ARRAY,
  parNummer: null,
  partner:null,
  kommunikationswege:null,
  partnererweiterterhaushalt:null,
  kundenprofil:null,
  druckwege:null,
  ladeDruckwege:null,
  editVsnr:null,
  spartenMappings:null,
  haushaltspartner:null,
  showDokumentView: false,
  loadingDokumentView: false,
  dokumentViewVsnr: null,
  saveOnlineDruckwegOngoing: false,
  saveOnlineDruckwegTempVsnr: null,
  saveOfflineDruckwegOngoing: false,
  onDruckKennzeichenSwitchValue: 'nein',
  currentPage: 0
};

const contentSlice = createSlice({
  name: 'content',
  initialState: initialSucheState,
  reducers: {
    suche() {
      // Trigger für SAGA Workflow
    },
    saveOnlineDruckweg(state, action) {
      // Trigger für SAGA Workflow
      state.saveOnlineDruckwegOngoing = true;
    },
    ladeErweiterterHaushalt(state, action){
      // Trigger für SAGA Workflow
    },
    ladeErweiterterHaushaltSuccess(state, action){
      state.partnererweiterterhaushalt = action.payload;
    },
    ladeErweiterterHaushaltError(state, action){
      state.partnererweiterterhaushalt = null;
    },
    saveOfflineDruckweg(state, action){
      // Trigger für SAGA Workflow
      state.saveOnlineDruckwegOngoing = true;
    },
    loadSaveOfflineDruckwegSuccess(state, action) {
      state.editVsnr = null;
      state.saveOnlineDruckwegOngoing = false;
      state.saveOnlineDruckwegTempVsnr = null;
    },
    loadSaveOfflineDruckwegError(state, action) {
      state.editVsnr = null;
      state.saveOnlineDruckwegOngoing = false;
      state.saveOnlineDruckwegTempVsnr = null;
    },
    saveOfflineDruckwegTemp(state, action){
      // Trigger für SAGA Workflow
      state.saveOnlineDruckwegTempVsnr = action.payload;
    },
    setCurrentPage(state, action){
      state.currentPage = action.payload;
    },
    onDruckKennzeichenSwitchClicked(state, action){
      state.saveOnlineDruckwegOngoing = true;
      state.onDruckKennzeichenSwitchValue = action.payload;
    },
    sucheStarted(state) {
      markRemoteLoading(state);
      state.suchergebnisse = EMPTY_ARRAY;
    },
    sucheSuccess(state, action) {
      markRemoteLoaded(state);
      state.suchergebnisse = action.payload || EMPTY_ARRAY;
    },
    sucheError(state, action) {
      markRemoteError(state, action);
    },
    setCurrentTab(state, action) {
      const tab = action.payload;
      if ([...state.view.availableTabs].includes(tab)) {
        state.view.currentTab = tab;
      }
    },
    setAvailableTabs(state, action) {
      const tabs = [...action.payload];
      const [firstTab] = tabs;
      state.view.availableTabs = tabs;
      state.view.currentTab = firstTab;
    },
    resetSucheForm(state) {
      state.form.maKuerzel = null;
    },
    setMaKuerzel(state, action) {
      state.form.maKuerzel = action.payload;
    },
    ladePartner(state, action){
      markRemoteLoading(state);
      state.parNummer  = action.payload;
    },
    ladeDruckwege(state, action){
      state.ladeDruckwege = true;
      state.parNummer  = action.payload;
    },
    loadPartnerDatenSuccess(state, action) {
      markRemoteLoaded(state);

      state.partner = action.payload.response.partner;
      state.kundenprofil = action.payload.response.kundenprofil;
      state.haushaltspartner = action.payload.response.haushaltsPartner;
      state.spartenMappings = action.payload.response.spartenMappings;
      state.kommunikationswege = action.payload.response.kommunikationswege;
    },
    loadPartnerDatenError(state, action) {
      markRemoteError(state, action);

      state.partner = null;
      state.kundenprofil = null;
      state.haushaltspartner = null;
    },
    loadDruckwegeSuccess(state, action) {
      markRemoteLoaded(state);

      state.druckwege = action.payload.response;
      state.ladeDruckwege = false;
      state.onDruckKennzeichenSwitchValue = 'nein';
    },
    loadDruckwegeError(state, action) {
      markRemoteError(state, action);

      state.druckwege = null;
      state.ladeDruckwege = false;
    },
    editVsnr(state, action){
      state.editVsnr = action.payload;
    },
    switch2DokumentView(state, action){
      state.showDokumentView = true;
      state.loadingDokumentView = true;
      state.dokumentViewVsnr = action.payload;
    },
    switch2DokumentViewSuccess(state, action){
      state.druckauftrage = action.payload.response;
      state.loadingDokumentView = false;
    },
    switch2DokumentViewError(state, action){
      state.druckauftrage = null;
      state.loadingDokumentView = false;
    },
    switch2ContractView(state, action){
      state.showDokumentView = false;
      state.dokumentViewVsnr = null;
    },
    loadSaveOnlineDruckwegSuccess(state, action) {
      state.editVsnr = null;
      state.saveOnlineDruckwegOngoing = false;
    },
    loadSaveOnlineDruckwegError(state, action) {
      state.editVsnr = null;
      state.saveOnlineDruckwegOngoing = false;
    }
  }
});

export const ContentActions = contentSlice.actions;
export default contentSlice;
