import React from 'react';
import {useSelector} from "react-redux";
import {Grid} from "@mui/material";
import Widget from "../../../components/Widget";
import {selectContentKundenprofil} from "../../../store/content/ContentSelector";
import {isEmpty} from "@cos/rcl-future/utils";

import VertriebswegSparteFormatter from "./formatter/VertriebswegSparteFormatter";
import {DataTable} from "@cos/rcl-future/components";


function Erstvertrag() {

    const kundenprofil = useSelector(selectContentKundenprofil);
    const title = "Vertriebsweg Erstvertrag";

    const columns =
        [
            {
                id: 'vertriebswegNummer',
                dataField: 'vertriebswegNummer',
                text: 'VW',
                headerStyle: {width: 50},
            },
            {
                id: 'vertriebswegName',
                dataField: 'vertriebswegName',
                text: 'Name Vertriebsweg',
                headerStyle: {width: 2},
            },
            {
                id: 'vertriebswegDatum',
                dataField: 'vertriebswegDatum',
                text: 'Datum',
                headerStyle: {width: 100},
            },
            {
                id: 'vertriebswegSparte',
                dataField: 'vertriebswegSparte',
                text: 'Sparte',
                headerStyle: {width: 150},
                // formatter: (row: Vertriebsweg) => <VertriebswegSparteFormatter vertriebswegsparteKey={row.vertriebswegSparte} />
            }
        ];

    const rows = [kundenprofil?.vertriebsweg].filter(
        v => v && !isEmpty(v.verNummer)
    );

    return (
        <Widget title={`${title}`}>
            <Grid container spacing={1}>
                <Grid size={{ xs: 12}}>
                    <strong>Kunde seit: </strong>
                    {/*// TODO : ????*/}
                    {!isEmpty(kundenprofil?.vertragsinfoListeEintrag) ? kundenprofil?.kundeSeit : ''}
                </Grid>
                <Grid size={{ xs: 12}}>
                    <DataTable
                        rows={rows}
                        columns={columns}
                        onRowClick={() => {}}

                        // getRowId={(row) => row.vertriebswegNummer}
                    />
                </Grid>
            </Grid>
        </Widget>
    );
}

export default Erstvertrag;