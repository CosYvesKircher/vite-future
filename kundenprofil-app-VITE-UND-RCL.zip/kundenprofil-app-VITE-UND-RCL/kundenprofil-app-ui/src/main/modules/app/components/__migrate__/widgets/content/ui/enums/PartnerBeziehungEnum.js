import {createEnum} from '../../../../utils/enum/enum';

const PartnerBeziehungEnum = createEnum('DruckKennzeichenEnum', {
  ENGER: {
    value: 'enger',
    label: 'enger'
  },
  ERWEITERT: {
    value: 'erweitert',
    label: 'erweitert'
  }
});

export default PartnerBeziehungEnum;
