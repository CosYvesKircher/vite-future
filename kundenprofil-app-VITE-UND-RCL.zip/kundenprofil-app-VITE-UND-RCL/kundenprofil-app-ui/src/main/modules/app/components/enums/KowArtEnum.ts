export enum KowArtEnum {
    UNBEKANNT = "",
    TELEFON = "Telefon",
    FAX = "Fax",
    EMAIL = "E-Mail",
    MOBILFUNK = "Mobilfunk"
}
export default KowArtEnum;
