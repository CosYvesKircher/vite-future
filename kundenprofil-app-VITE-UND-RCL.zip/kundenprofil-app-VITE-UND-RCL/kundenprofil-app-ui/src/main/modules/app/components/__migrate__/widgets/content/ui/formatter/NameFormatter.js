import {makeStyles} from '@material-ui/core';
import React from 'react';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles(theme => ({
  root: {
    display: 'flex',
    justifyContent: 'center'
  },
  iconWrapper: {
    '&:not(:last-child)': {
      marginRight: theme.spacing(1)
    }
  }
}));

NameFormatter.propTypes = {
  row: PropTypes.shape({
    vorname: PropTypes.string,
    name: PropTypes.string
  }).isRequired
};

export default function NameFormatter({row}) {
  return (
      <Typography color={'initial'}>
        {row.vorname + ' ' + row.name}
      </Typography>
  );
}