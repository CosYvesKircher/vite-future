import React, {useCallback, useEffect} from 'react';
import {useForm} from 'react-hook-form';
import {useDispatch, useSelector} from 'react-redux';

import Widget from '../../../../components/Widget';
import ContentSelectors from '../../contentSelectors';
import {makeStyles} from '@material-ui/core/styles';
import {ContentActions} from '../../contentSlice';
import {Box, Grid} from '@material-ui/core';
import {REMOTE_STATE} from '../../../../utils/rest/restUtils';
import LoadingProgress from '@cos/react-component-library/components/spinner/LoadingProgress';
import Text from '@cos/react-component-library/components/text/Text';
import DataTable from '@cos/react-component-library/components/datatable/DataTable';
import SparteFormatter from '../formatter/SparteFormatter';
import Typography from '@material-ui/core/Typography';
import {Colors} from '@cos/react-component-library/styles/theme';
import parseDatumUhrzeit from '../../../../utils/parseDatumUhrzeit';
import NameFormatter from '../formatter/NameFormatter';
import NumberFormatter from '../formatter/NumberFormatter';
import BeziehungFormatter from '../formatter/BeziehungFormatter';
import {formatCurrency} from '../../../../utils/numberUtils';
import {Checkbox, ToggleSwitch} from '@cos/react-component-library';
import PartnerBeziehungEnum from '../enums/PartnerBeziehungEnum';

const useWidgetStyles = makeStyles({
    root: {
        display: 'flex',
        flexDirection: 'column',
        paddingTop: 5,
        margin: 0,
        overflow: 'hidden',
        height: '100%',
        width: '100%'
    },
    contentWrapper: {
        padding: 0,
        margin: 0,
        height: '100%'
    },
    content: {
        padding: 0,
        margin: 0
    }
});

const useContentStyles = makeStyles(() => ({
    contentArea: {
        padding: 0,
        margin: 0,
        display: 'flex',
        paddingBottom: 5
    },
    area: {
        paddingTop:6,
        paddingLeft: 8,
        paddingBottom: 2
    },
    table: {
        paddingTop: 8,
        paddingLeft: 10
    },
    topic: {
        paddingLeft: 10,
        fontWeight: '600',
        fontSize:'1.4rem',
        textDecoration: 'underline'
    },
    label: {
        backgroundColor: Colors.COSMOS_BLAU_HELLER_5,
        fontWeight: '600'
    },
    labelbetrag: {
        padding: '2px',
        fontWeight: '600'
    },
    zahlungsmorallabel: {
        backgroundColor: Colors.COSMOS_BLAU_HELLER_5,
        padding: '2px 10px 2px 5px',
        fontWeight: '600'
    },
    scoringgruen: {
        backgroundColor: Colors.COSMOS_BUTTON_GRUEN,
        padding: '2px 10px 2px 5px',
        fontWeight: '600'
    },
    scoringrot: {
        backgroundColor: Colors.COSMOS_ROT,
        color: 'white',
        padding: '2px 10px 2px 5px',
        fontWeight: '600'
    },
    scoringorange: {
        backgroundColor: Colors.COSMOS_ORANGE,
        padding: '2px 10px 2px 5px',
        fontWeight: '600'
    },
    errorlabel: {
        backgroundColor: Colors.COSMOS_APP_BACKGROUND,
        padding: '2px 10px 2px 5px',
        fontWeight: '600',
        color: Colors.COSMOS_ROT
    },
    gridItem: {
        padding: '0.5rem 1rem'
    },
    center: {
        textAlign: 'center'
    },
    box: {
        height: '100%',
        maxHeight: '150px',
        overflow: 'scroll'
    },
    boxpartner: {
        height: '110px',
        maxHeight: '150px',
        overflow: 'scroll'
    },
    boxdatatable: {
        height: '100%',
        width: 1000
    },
    datatable: {
        display: 'flex',
        height: '100%',
        paddingRight:20
    },
    dataTable: {
        width: 320,
        marginRight:20,
        cursor: 'none'
    },
    griditem: {
        display: 'flex',
        paddingRight: '8px'
    }
}));

function createVersichertesRisikoPanel(contentClasses, kundenprofil) {

    const columnsRisiko =
      [
          {
              id: 'sparte',
              dataField: 'sparte',
              text: 'Sparte',
              formatter: <SparteFormatter/>
          },
          {
              id: 'anzahl',
              align: 'center',
              dataField: 'anzahlVertraege',
              text: 'Anzahl',
              headerStyle: {width: 50}
          },
          {
              id: 'jahresnetto',
              align: 'right',
              dataField: 'beitrag',
              text: 'Aktueller Jahres-Nettobeitrag',
              headerStyle: {width: 100},
              formatter: <NumberFormatter as="currency" dataField={'beitrag'} />
          }
      ];

    const vertragsSparten=[]
    const fremdvertragsSparten =[];
    if(kundenprofil.vertragsinfoSparteListeEintrag){
        kundenprofil.vertragsinfoSparteListeEintrag.forEach((vertragsSparte) => {
            if(vertragsSparte.anzahlVertraege >= 0){
                vertragsSparten.push(vertragsSparte);
            } else{
                fremdvertragsSparten.push(vertragsSparte);
            }
        });
    }

    return <>
        <label className={contentClasses.topic}>
            Versichertes Risiko
        </label>

        <Grid className={contentClasses.contentArea}>
            <Grid className={contentClasses.area} container spacing={2}>
                <Grid item xs={16}>
                    <Grid className={contentClasses.table} container spacing={3}>
                        <Box className={contentClasses.box}>
                            <DataTable
                              rows={vertragsSparten}
                              columns={columnsRisiko}
                              className={contentClasses.dataTable}
                            />
                        </Box>
                    </Grid>

                    <Grid className={contentClasses.table} container spacing={3}>
                        <Box className={contentClasses.box} hidden>
                            <DataTable
                                rows={fremdvertragsSparten}
                                columns={columnsRisiko}
                                className={contentClasses.dataTable}
                            />
                        </Box>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    </>;
}

function createKundensaldoLabel(kundenprofil, contentClasses) {
    if (kundenprofil?.zahlungsinfo?.aktuellerKundensaldo < 0){
        return (
            <label className={contentClasses.errorlabel}>
                Aktueller Kundensaldo
            </label>
        );
    }

    return (
        <label className={contentClasses.zahlungsmorallabel}>
            Aktueller Kundensaldo
        </label>
    );
}

function createKundensaldoValue(kundenprofil) {
    if (kundenprofil?.zahlungsinfo?.aktuellerKundensaldo){
        return (
          formatCurrency(kundenprofil?.zahlungsinfo?.aktuellerKundensaldo)
        );
    }

    return (0);
}

function createScoringLabel(kundenprofil, contentClasses) {
    if (kundenprofil?.zahlungsinfo?.scoringWert === 'Grün'){
        return (
                <label className={contentClasses.scoringgruen}>
                    Scoring
                </label>
        );
    }else if(kundenprofil?.zahlungsinfo?.scoringWert === 'Rot'){
        return (
                <label className={contentClasses.scoringrot}>
                    Scoring
                </label>
        );
    }else if(kundenprofil?.zahlungsinfo?.scoringWert === 'Orange'){
        return (
                <label className={contentClasses.scoringorange}>
                    Scoring
                </label>
        );
    }

    return (
        <Typography color={'initial'} display={'block'}>
            <label className={contentClasses.zahlungsmorallabel}>
                Scoring
            </label>
        </Typography>
    );
}

function createScoringValue(kundenprofil, contentClasses) {
    return (
        <Typography display={'block'}>
            {parseDatumUhrzeit(kundenprofil?.zahlungsinfo?.scoringDatum)}
        </Typography>
    );
}

function createZahlungsmoralPanel(contentClasses, kundenprofil) {
    return <>
        <label className={contentClasses.topic}>
            Zahlungsmoral
        </label>

        <Grid className={contentClasses.contentArea}>
            <Grid className={contentClasses.area} container >
                <Grid item xs={4} className={contentClasses.griditem}>
                    {createKundensaldoLabel(kundenprofil, contentClasses)}
                    {createKundensaldoValue(kundenprofil)}
                </Grid>
                <Grid item xs={3} className={contentClasses.griditem}>
                    {createScoringLabel(kundenprofil, contentClasses)}
                    {createScoringValue(kundenprofil,contentClasses)}
                </Grid>
                <Grid item xs={5} className={contentClasses.griditem}>
                    <label className={contentClasses.zahlungsmorallabel}>Mahnverfahren</label>
                    {kundenprofil?.zahlungsinfo?.anzahlMahnverfahrenOffen}
                </Grid>
            </Grid>
        </Grid>
    </>;
}
function createPartnerPanel(contentClasses, kundenprofil, haushaltsPartner, onPartnerBeziehungSwitchClicked,
                            partnererweiterterhaushalt, checked, setChecked, onCheckboxChange) {
    let anspruchsteller = 0;
    let empfehler = 0;
    let kundenbeschwerden = 0;
    if(kundenprofil.besondereRollen){
        kundenprofil.besondereRollen.forEach((rolle) => {
            if(rolle.rolle === 'AS'){
                anspruchsteller++;
            }
            if(rolle.rolle === 'EMP'){
                empfehler++;
            }
        });
    }

    if(kundenprofil.beschwerdeListeEintrag){
        kundenprofil.beschwerdeListeEintrag.forEach((beschwerde) => {
            kundenbeschwerden++;
        });
    }

    const columnsPartner =
        [
            {
                id: 'name',
                dataField: 'name',
                text: 'Name',
                formatter: <NameFormatter/>
            },
            {
                id: 'geburtsDatum',
                dataField: 'geburtsDatum',
                text: 'geb.',
                headerStyle: {width: 50}
            },
            {
                id: 'beziehung',
                dataField: 'haushaltsRolle',
                text: 'Beziehung',
                formatter: <BeziehungFormatter/>,
                headerStyle: {width: 60}
            }
        ];

    const columnsErweiterterPartnerHaushalt =
        [
            {
                id: 'name',
                dataField: 'name',
                text: 'Name',
                formatter: <NameFormatter/>,
                headerStyle: {width: 250}
            },
            {
                id: 'geburtsDatum',
                dataField: 'geburtsDatum',
                text: 'Geburtsdatum',
                headerStyle: {width: 150}
            },
            {
                id: 'beziehung',
                dataField: 'haushaltsRolle',
                text: 'Beziehung',
                formatter: (row) => {
                    return 'Erweitert';
                },
                headerStyle: {width: 150}
            }
        ];

    if(haushaltsPartner && haushaltsPartner.length > 0){
        return <>
            <div style={{display: 'flex'}}>
                <label className={contentClasses.topic}>
                    Partner
                </label>
                <div style={{display: 'flex', padding: 0, width: '100%', justifyContent: 'flex-end'}}>
                    <Checkbox value={checked}
                              onChange={onCheckboxChange}
                              label={'Erweiterter Haushalt anzeigen'}
                              style={{padding: 0}}
                    />
                </div>
            </div>

            <Grid className={contentClasses.contentArea}>
                <Grid className={contentClasses.area} container spacing={2}>
                    <Grid item xs={8}>
                        <Grid className={contentClasses.area} container spacing={3}>
                            <Box className={contentClasses.boxpartner}>
                                <DataTable
                                    rows={haushaltsPartner}
                                    columns={columnsPartner}
                                    className={contentClasses.dataTable}
                                />
                            </Box>
                            <Box className={contentClasses.boxpartner}>
                                <div style={{paddingBottom: 4}}/>
                                {partnererweiterterhaushalt &&
                                    <DataTable
                                        rows={partnererweiterterhaushalt}
                                        columns={columnsErweiterterPartnerHaushalt}
                                        className={contentClasses.dataTable}
                                    />
                                }
                            </Box>
                        </Grid>
                    </Grid>

                    <Grid item xs={4}>
                        <div style={{display: 'flex', flexDirection: 'column'}}>
                            <label className={contentClasses.zahlungsmorallabel}>
                                Kundenbeschwerden
                            </label>
                            <div className={contentClasses.labelbetrag}>
                                {kundenbeschwerden}
                            </div>

                            <div style={{padding: 4}}/>
                            <label className={contentClasses.zahlungsmorallabel}>
                                Anspruchssteller
                            </label>
                            <div className={contentClasses.labelbetrag}>
                                {anspruchsteller}
                            </div>

                            <div style={{padding: 4}}/>
                            <label className={contentClasses.zahlungsmorallabel}>
                                Empfehler
                            </label>
                            <div className={contentClasses.labelbetrag}>
                                {empfehler}
                            </div>
                        </div>
                    </Grid>
                </Grid>
            </Grid>
        </>;
    }else{
        return <>
            <label className={contentClasses.topic}>
                Partner
            </label>

            <Grid className={contentClasses.contentArea}>
                <Grid className={contentClasses.area} container spacing={2}>
                    <Grid item xs={16}>
                        <Grid className={contentClasses.table} container spacing={3}>
                            Keine Haushaltspartner vorhanden.
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>

            <Grid className={contentClasses.contentArea}>
                <Grid className={contentClasses.area} container spacing={6}>
                    <Grid item xs={2}>
                        <label className={contentClasses.label}>
                            Kundenbeschwerden
                        </label>
                    </Grid>
                    <Grid item xs={1}>
                        {kundenbeschwerden}
                    </Grid>
                    <Grid item xs={2}>
                        <label className={contentClasses.label}>
                            Anspruchssteller
                        </label>
                    </Grid>
                    <Grid item xs={1}>
                        {anspruchsteller}
                    </Grid>
                    <Grid item xs={2}>
                        <label className={contentClasses.label}>
                            Empfehler
                        </label>
                    </Grid>
                    <Grid item xs={1}>
                        {empfehler}
                    </Grid>
                </Grid>
            </Grid>
        </>;
    }
}

function createWirtschaftlichkeitPanel(contentClasses, kundenprofil) {
    const columnsRentablitaet =
      [
          {
              id: 'sparte',
              dataField: 'sparte',
              text: 'Sparte'
          },
          {
              id: 'anzahl',
              align: 'center',
              dataField: 'anzahl',
              text: 'Anzahl',
              headerStyle: {width: 40}
          },
          {
              id: 'summe',
              dataField: 'summe',
              text: 'Summe',
              headerStyle: {width: 50},
              formatter: <NumberFormatter as="currency" dataField={'summe'}/>
          }
      ];

    const rowsRentablitaet = [
        {id: 1,
            sparte: 'Leistung Leben',
            anzahl: kundenprofil?.kundenprofilRentabilitaetGesamt?.anzahlLeistung,
            summe: kundenprofil?.kundenprofilRentabilitaetGesamt?.summeLeistung
        },
        {id: 2,
            sparte: 'Schaden Komposit',
            anzahl: kundenprofil?.kundenprofilRentabilitaetGesamt?.anzahlSchaden,
            summe: kundenprofil?.kundenprofilRentabilitaetGesamt?.summeSchaden
        }
    ];

    return <>
        <label className={contentClasses.topic}>
            Wirtschaftlichkeit/Rentabilität
        </label>

        <Grid className={contentClasses.contentArea}>
            <Grid className={contentClasses.area} container spacing={2}>
                <Grid item xs={8}>
                    <Grid className={contentClasses.area} container spacing={3}>
                        <Box className={contentClasses.box}>
                            <DataTable
                              rows={rowsRentablitaet}
                              columns={columnsRentablitaet}
                              className={contentClasses.dataTable}
                            />
                        </Box>
                    </Grid>
                </Grid>

                <Grid item xs={4}>
                    <div style={{display: 'flex', flexDirection: 'column'}}>
                        <label className={contentClasses.label}>
                            Gesamtbetrag:
                        </label>
                        <div className={contentClasses.labelbetrag}>
                            {formatCurrency(kundenprofil?.kundenprofilRentabilitaetGesamt?.gesamtJahresBeitrag)}
                        </div>

                        <div style={{padding: 4}}/>
                        <label className={contentClasses.label}>
                            Komposit-Schadenquote:
                        </label>
                        <div className={contentClasses.labelbetrag}>
                            {kundenprofil?.kundenprofilRentabilitaetGesamt?.kompositSchadenquote}
                        </div>
                    </div>
                </Grid>
            </Grid>
        </Grid>
    </>;
}

function createKundenprofilPanel(contentClasses, kundenprofil, haushaltsPartner, onPartnerBeziehungSwitchClicked,
                                 partnererweiterterhaushalt,checked, setChecked, onCheckboxChange){
    return (
        <div>
            <hr/>
            {createWirtschaftlichkeitPanel(contentClasses, kundenprofil)}

            <hr/>
            {createVersichertesRisikoPanel(contentClasses, kundenprofil)}

            <hr/>
            {createZahlungsmoralPanel(contentClasses, kundenprofil)}

            <hr/>
            {createPartnerPanel(contentClasses, kundenprofil, haushaltsPartner, onPartnerBeziehungSwitchClicked,
                partnererweiterterhaushalt, checked, setChecked, onCheckboxChange)}
        </div>
    );
}

function KundenprofilWidget() {
    const widgetClasses = useWidgetStyles();
    const contentClasses = useContentStyles();
    const {remoteState} = useSelector(ContentSelectors.selectRemoteState);

    const {handleSubmit} = useForm();
    const dispatch = useDispatch();
    const kundenprofil = useSelector(ContentSelectors.selectKundenprofil);
    const haushaltsPartner = useSelector(ContentSelectors.selectHaushaltsPartner);
    const partnererweiterterhaushalt = useSelector(ContentSelectors.selectPartnererweiterterhaushalt);

    const [checked, setChecked] = React.useState(true);
    const onCheckboxChange = (event) => {
        setChecked(event.target.checked);
        onPartnerBeziehungSwitchClicked(event.target.checked ? 'erweitert' : 'enger', kundenprofil);
    };

    const onSubmit = useCallback((formValues) => {
        dispatch(ContentActions.suche(formValues));
    }, [dispatch]);

    const onPartnerBeziehungSwitchClicked = (filterValue, kundenprofil) => {
        console.log('Aendern des Partner Beziehung auf: ' + filterValue);
        dispatch(ContentActions.ladeErweiterterHaushalt({
            value: filterValue,
            parNummer: kundenprofil.parNummer
        }));
    };

    useEffect(() => {
        if (kundenprofil && !partnererweiterterhaushalt) {
            onPartnerBeziehungSwitchClicked('erweitert', kundenprofil);
        }
    }, [kundenprofil, partnererweiterterhaushalt, onPartnerBeziehungSwitchClicked ]);

    if (remoteState === REMOTE_STATE.LOADED && kundenprofil) {
        return (
            <Widget classes={widgetClasses} title="Informationen">
                <form onSubmit={handleSubmit(onSubmit)}>
                    {createKundenprofilPanel(contentClasses, kundenprofil, haushaltsPartner, onPartnerBeziehungSwitchClicked,
                        partnererweiterterhaushalt, checked, setChecked, onCheckboxChange)}
                </form>
            </Widget>
        );
    } else if (remoteState === REMOTE_STATE.LOADED && !kundenprofil && !haushaltsPartner) {
        return (
            <Widget classes={widgetClasses} title="Informationen">
                Kundenprofil konnte nicht gefunden werden!
            </Widget>
        );
    } else if (remoteState === REMOTE_STATE.ERROR) {
        return (
            <Widget classes={widgetClasses} title="Informationen">
                Fehler beim Laden des Kundenprofils!
            </Widget>
        );
    } else {
        return (
            <Widget classes={widgetClasses}>
                <div>
                    <LoadingProgress/>
                    <Text className={contentClasses.center} value={'wird geladen...'}/>
                </div>
            </Widget>
        );
    }
}

export default KundenprofilWidget;
