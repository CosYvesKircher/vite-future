import {describe, expect, it} from 'vitest';
import {render, screen} from '../../../../../test-utils';
import Partnerdaten from '../Partnerdaten';
import {ContentStateType} from "../../../../store/content/ContentStoreTypes";
import {RemoteLoadingState} from "../../../../utils/rest/RemoteStateUtils";

describe('<Partnerdaten>', () => {
    it('zeigt Partnernamen im Title an', () => {
        const contentOverrides : ContentStateType = {

                remote: {
                    loadingState: RemoteLoadingState.loaded,
                    remoteError: null
                },
                partner: {
                    partnerNummer: 123,
                    anrede: 'HERR',
                    anredeCode: 1,
                    name: 'MAX',
                    vorname: 'MUSTERMANN',
                    geburtsDatum: '01.01.1990',
                    geburtsJahr: undefined,
                    adressen: [
                        {
                            validator: undefined,
                            adressId: '0',
                            laufendeNummer: '1',
                            strasse: 'TESTSTRASSE',
                            zusatz: undefined,
                            hausnummer: '1',
                            plz: '66117',
                            ort: 'Saarbrücken',
                            land: 'D',
                            adressTyp: 'HAUPTWOHNSITZ',
                            adresstypCode: undefined,
                            gueltigAb: '05.09.2022',
                            gueltigBis: '31.12.2999',
                            inaktivAb: undefined,
                            updateZahl: 1
                        }
                    ],
                    sterbedatum: undefined,
                    status: 'UNBEKANNT',
                    titel: 'KEIN_TITEL',
                    berufBezeichnung: 'SOFTWAREENTWICKLER',
                    berufCode: '441006',
                    letzteAenderung: '20.03.2023',
                    scoring: 'GRAY',
                    beschaeftigungsverh: 'Angestellter',
                    beschaeftigungCode: 'ANG',
                    familienStand: 'UNBEKANNT',
                    familienStandCode: undefined,
                    anzahlKinder: undefined,
                    geburtslandCode: undefined,
                    geburtsOrt: undefined,
                    staatsangehoerigkeitCode: 'D',
                    haushaltsRolle: 'CHEF',
                    updateZahl: 1
                }

        };

        render(<Partnerdaten />, {
            preloadedState: {
                ...{content: contentOverrides}
            }
        });
        expect(screen.getByText("Kundenprofil von MUSTERMANN MAX")).toBeInTheDocument();
        expect(screen.getByText("MUSTERMANN MAX")).toBeInTheDocument();
    });
});