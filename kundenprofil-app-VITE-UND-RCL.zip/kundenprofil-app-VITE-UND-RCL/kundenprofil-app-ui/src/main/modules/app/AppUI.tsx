// import AppErrorDialog from '@cos/react-component-library/components/dialog/AppErrorDialog';

// import {makeStyles} from '@material-ui/core/styles';
import clsx from 'clsx';
import React from 'react';
import {useTranslation} from 'react-i18next';

// import ErrorHint from '../../components/ErrorHint/ErrorHint';
// import LoadingHint from '../../components/LoadingHint/LoadingHint';

// import {REMOTE_STATE} from '../../utils/rest/restUtils';
// import ErstvertragWidget from '../content/ui/widgets/ErstvertragWidget';
// import PartnerdatenWidget from '../content/ui/body/PartnerdatenWidget';
// import KundenprofilWidget from '../content/ui/body/KundenprofilWidget';
// import DruckwegWidget from '../content/ui/widgets/DruckwegWidget';
import PropTypes from 'prop-types';
// import {useStyles} from "tss-react";
import {RemoteState} from "@cos/rcl-future/enums";

import {HeaderBar} from '@cos/rcl-future/components'
import {Box, Grid} from "@mui/material";
import {styled} from '@mui/material/styles';
import {useSelector} from "react-redux";

import LoadingWrapper from "../../components/LoadingWrapper";

import Partnerdaten from "./components/Partnerdaten";


import {selectUserRemote} from "../../store/user/UserSelector";
import {RemoteData} from "../../utils/rest/RemoteStateUtils";
import {selectContentRemote} from "../../store/content/ContentSelector";
import Erstvertrag from "./components/Erstvertrag";
import Kundenprofil from "./components/Kundenprofil";
import DruckwegWidget from "./components/druckweg/DruckwegWidget";


// import Kundenprofil from "./components/Kundenprofil";

// const useStyles = makeStyles((theme: Theme) => ({
//   headerContainer: {
//     width: '100%',
//   },
//   main: {
//     // display: 'block',
//     // paddingTop: theme.spacing(1),
//     // paddingBottom: theme.spacing(1),
//     // paddingRight: theme.spacing(1),
//     // paddingLeft: theme.spacing(1),
//     padding: useTheme().spacing(1),
//     // width: '100%',
//     // height: 'calc(100vh - 50px)' // 50px = HEIGHT OF MainAppBar
//   },
//   gridContainer: {
//   //   display: 'grid',
//   //   gridTemplateRows: '220px 200px calc(100vh - 500px)',
//   //   gridTemplateColumns: 'minmax(500px,40%) auto',
//   //   gridTemplateAreas: ['"partnerdaten kundenprofil"', '"kooperationen kundenprofil"', '"druckweg kundenprofil"'].join(' '),
//   //   gridColumnGap: 5,
//   //   gridRowGap: 5,
//   //   height: '100%',
//   //   width: '100%',
//   //   overflowY: 'hidden'
//   },
//   gridItem: {
//   //   overflow: 'auto'
//   },
//   partnerdaten: {
//   //   gridArea: 'partnerdaten'
//   },
//   partnerdatenSmall: {
//   //   gridArea: 'partnerdaten',
//   //   height: '5%'
//   },
//   kundenprofil: {
//     // gridArea: 'kundenprofil'
//   },
//   druckweg: {
//     // gridArea: 'druckweg'
//   },
//   kooperationen: {
//   //   gridArea: 'kooperationen',
//   //   backgroundColor: Colors.COSMOS_INPUT_BACKGROUND_FILLED,
//   //   overflow: 'auto'
//   }
// }));

const AppUiDiv = styled('div')(({theme}) => ({
    width: '100%',
    height: '100vh',
    overflowY: 'hidden',
    overflowX: 'hidden',
    '.headerContainer': {
        width: '100%',
    },
    '.main': {
        padding: theme.spacing(1),
        width: '100%',
        height: 'calc(100vh - 100px)' // 50px = HEIGHT OF MainAppBar
    }

}));

function AppUI() {

    const userRemoteState: RemoteData = useSelector(selectUserRemote);
    const contentRemoteState = useSelector(selectContentRemote);

    return (

        <AppUiDiv>
            {/*<MainAppBar/>*/}
            <div className="headerContainer">
                {/*TODO richtiger MainAppBar*/}
                <HeaderBar appName={'Kundenprofil-App'} appKuerzel={'KP'} iconButtons={[]}/>
            </div>

            <main className="main">
                <LoadingWrapper
                    remoteLoadingState={userRemoteState.loadingState}
                    widgetLoadingTitle="Lädt Userdaten..."
                    widgetErrorText="Fehler beim Laden des Users!"
                >
                    <Box sx={{flexGrow: 1, height: '100%'}}>
                        <Grid container spacing={2} style={{height: '100%'}}>
                            <Grid size={6} style={{height: '100%'}}>
                                <LoadingWrapper
                                    remoteLoadingState={contentRemoteState.loadingState}
                                    widgetLoadingTitle="Lädt Partnerdaten..."
                                    widgetErrorText="Fehler beim Laden der Partnerdaten!"
                                    style={{height: '100%'}}
                                >
                                    <Partnerdaten/>
                                    <Erstvertrag />
                                    <DruckwegWidget />
                                </LoadingWrapper>
                            </Grid>
                            <Grid size={6}>
                                <LoadingWrapper
                                    remoteLoadingState={contentRemoteState.loadingState}
                                    widgetLoadingTitle="Lädt Kundenprofil..."
                                    widgetErrorText="Fehler beim Laden des Kundenprofils!"
                                >
                                    <Kundenprofil />
                                </LoadingWrapper>
                            </Grid>

                        </Grid>
                    </Box>
                </LoadingWrapper>
            </main>
        </AppUiDiv>
    );
}

//   <div className={classes.gridContainer}>
//     <div
//       className={clsx(classes.gridItem, classes.partnerdaten)}
//       data-testid="app-grid-partnerdaten"
//     >
//       <PartnerdatenWidget/>
//       PartnerdatenWidget
//     </div>
//     <div
//       className={clsx(classes.gridItem, classes.kooperationen)}
//       data-testid="app-grid-kooperationen"
//     >
//       <ErstvertragWidget/>
//       ErstvertragWidget
//     </div>
//     <div
//       className={clsx(classes.gridItem, classes.druckweg)}
//       data-testid="app-grid-druckweg"
//     >
//       <DruckwegWidget/>
//       DruckwegWidget
//     </div>
//     <div
//       className={clsx(classes.gridItem, classes.kundenprofil)}
//       data-testid="app-grid-kundenprofil"
//     >
//       <KundenprofilWidget/>
//       KundenprofilWidget
//     </div>
//   </div>

AppUI.propTypes = {
    remoteState: PropTypes.string.isRequired,
    remoteError: PropTypes.any,
    userCanOpenApp: PropTypes.bool
};

export default AppUI;
